import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Bot, MessageSquare, Users, ArrowUpRight, Download, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
import { useLocalStorage } from "/src/hooks/useStorage.ts";
import { downloadProjectZip } from "/src/services/exportService.ts";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport5_react["useState"];
export default function Dashboard() {
  const [bots] = useLocalStorage("bots", []);
  const [messages] = useLocalStorage("messages", []);
  const [clients] = useLocalStorage("clients", []);
  const [isDownloading, setIsDownloading] = useState(false);
  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      await downloadProjectZip();
    } finally {
      setIsDownloading(false);
    }
  };
  const metrics = [
    { title: "Total Bots", value: bots.length, icon: Bot, trend: "+0" },
    { title: "Total Mensagens", value: messages.length, icon: MessageSquare, trend: "+0" },
    { title: "Total Clientes", value: clients.length, icon: Users, trend: "+0" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-12", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-end", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "font-serif text-4xl text-champagne", children: "Visão Geral" }, void 0, false, {
          fileName: "/app/applet/src/components/Dashboard.tsx",
          lineNumber: 33,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "font-cinzel text-[10px] text-platina/40 tracking-widest uppercase mt-2", children: "Bem-vindo ao centro de comando TeleMassa" }, void 0, false, {
          fileName: "/app/applet/src/components/Dashboard.tsx",
          lineNumber: 34,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/Dashboard.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleDownload,
          disabled: isDownloading,
          className: "btn-primary flex items-center gap-3 px-6 py-3 text-xs",
          children: [
            /* @__PURE__ */ jsxDEV(Download, { size: 16, className: isDownloading ? "animate-bounce" : "" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 41,
              columnNumber: 11
            }, this),
            isDownloading ? "Preparando ZIP..." : "Baixar Site no ZIP"
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/applet/src/components/Dashboard.tsx",
          lineNumber: 36,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/Dashboard.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        className: "grid grid-cols-1 md:grid-cols-3 gap-8",
        children: metrics.map((metric, index) => /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0, y: 20 },
            animate: { opacity: 1, y: 0 },
            transition: { delay: index * 0.08 },
            className: "glass-card p-8 flex flex-col justify-between h-[200px] relative overflow-hidden",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "font-serif text-5xl font-black bg-[linear-gradient(to_bottom,#D4AF37,#F5D76E)] bg-clip-text text-transparent", children: metric.value }, void 0, false, {
                    fileName: "/app/applet/src/components/Dashboard.tsx",
                    lineNumber: 61,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-cinzel text-[11px] text-platina tracking-[0.15em] mt-1", children: metric.title.toUpperCase() }, void 0, false, {
                    fileName: "/app/applet/src/components/Dashboard.tsx",
                    lineNumber: 62,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "/app/applet/src/components/Dashboard.tsx",
                  lineNumber: 60,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-gold/5 rounded-[10px]", children: /* @__PURE__ */ jsxDEV(metric.icon, { className: "stroke-gold", size: 24 }, void 0, false, {
                  fileName: "/app/applet/src/components/Dashboard.tsx",
                  lineNumber: 65,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "/app/applet/src/components/Dashboard.tsx",
                  lineNumber: 64,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/components/Dashboard.tsx",
                lineNumber: 59,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4 border-t border-gold/10 pt-4", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-emerald text-xs font-mono", children: [
                /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 14, className: "mr-1" }, void 0, false, {
                  fileName: "/app/applet/src/components/Dashboard.tsx",
                  lineNumber: 70,
                  columnNumber: 17
                }, this),
                " ",
                metric.trend
              ] }, void 0, true, {
                fileName: "/app/applet/src/components/Dashboard.tsx",
                lineNumber: 69,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "/app/applet/src/components/Dashboard.tsx",
                lineNumber: 68,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-full h-[2px] bg-[linear-gradient(90deg,transparent,#D4AF37,transparent)]" }, void 0, false, {
                fileName: "/app/applet/src/components/Dashboard.tsx",
                lineNumber: 73,
                columnNumber: 13
              }, this)
            ]
          },
          index,
          true,
          {
            fileName: "/app/applet/src/components/Dashboard.tsx",
            lineNumber: 52,
            columnNumber: 11
          },
          this
        ))
      },
      void 0,
      false,
      {
        fileName: "/app/applet/src/components/Dashboard.tsx",
        lineNumber: 46,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-8", children: [
      /* @__PURE__ */ jsxDEV(
        motion.div,
        {
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: 0.3 },
          className: "lg:col-span-2 glass-card p-8",
          children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "font-serif text-2xl text-champagne mb-6", children: "Atividade Recente" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 85,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-64 bg-bg-1/50 rounded-[16px] border border-gold/10 flex items-center justify-center text-platina/30 font-mono text-sm", children: "[Gráfico de Atividade - Recharts]" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 86,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/applet/src/components/Dashboard.tsx",
          lineNumber: 79,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        motion.div,
        {
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: 0.4 },
          className: "glass-card p-8 flex flex-col justify-center items-center text-center space-y-4",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gold/10 rounded-full", children: /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 40, className: "text-gold" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 98,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 97,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "font-serif text-xl text-champagne", children: "Segurança & Backup" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 100,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-platina/60 text-xs font-sans leading-relaxed", children: "Seus dados são armazenados localmente. Recomendamos baixar o código do site regularmente para manter uma cópia de segurança em seu dispositivo." }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 101,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: handleDownload, className: "text-gold text-[10px] font-cinzel uppercase tracking-widest hover:underline", children: "Iniciar Backup Agora" }, void 0, false, {
              fileName: "/app/applet/src/components/Dashboard.tsx",
              lineNumber: 104,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/app/applet/src/components/Dashboard.tsx",
          lineNumber: 91,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/Dashboard.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/Dashboard.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkRhc2hib2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm90LCBNZXNzYWdlU3F1YXJlLCBVc2VycywgVHJlbmRpbmdVcCwgQXJyb3dVcFJpZ2h0LCBEb3dubG9hZCwgU2hpZWxkQ2hlY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IHVzZUxvY2FsU3RvcmFnZSB9IGZyb20gJy4uL2hvb2tzL3VzZVN0b3JhZ2UnO1xuaW1wb3J0IHsgQm90IGFzIEJvdFR5cGUsIE1lc3NhZ2UsIENsaWVudCB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IGRvd25sb2FkUHJvamVjdFppcCB9IGZyb20gJy4uL3NlcnZpY2VzL2V4cG9ydFNlcnZpY2UnO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZCgpIHtcbiAgY29uc3QgW2JvdHNdID0gdXNlTG9jYWxTdG9yYWdlPEJvdFR5cGVbXT4oJ2JvdHMnLCBbXSk7XG4gIGNvbnN0IFttZXNzYWdlc10gPSB1c2VMb2NhbFN0b3JhZ2U8TWVzc2FnZVtdPignbWVzc2FnZXMnLCBbXSk7XG4gIGNvbnN0IFtjbGllbnRzXSA9IHVzZUxvY2FsU3RvcmFnZTxDbGllbnRbXT4oJ2NsaWVudHMnLCBbXSk7XG4gIGNvbnN0IFtpc0Rvd25sb2FkaW5nLCBzZXRJc0Rvd25sb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc0Rvd25sb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBkb3dubG9hZFByb2plY3RaaXAoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNEb3dubG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IG1ldHJpY3MgPSBbXG4gICAgeyB0aXRsZTogJ1RvdGFsIEJvdHMnLCB2YWx1ZTogYm90cy5sZW5ndGgsIGljb246IEJvdCwgdHJlbmQ6ICcrMCcgfSxcbiAgICB7IHRpdGxlOiAnVG90YWwgTWVuc2FnZW5zJywgdmFsdWU6IG1lc3NhZ2VzLmxlbmd0aCwgaWNvbjogTWVzc2FnZVNxdWFyZSwgdHJlbmQ6ICcrMCcgfSxcbiAgICB7IHRpdGxlOiAnVG90YWwgQ2xpZW50ZXMnLCB2YWx1ZTogY2xpZW50cy5sZW5ndGgsIGljb246IFVzZXJzLCB0cmVuZDogJyswJyB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LXNlcmlmIHRleHQtNHhsIHRleHQtY2hhbXBhZ25lXCI+Vmlzw6NvIEdlcmFsPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWNpbnplbCB0ZXh0LVsxMHB4XSB0ZXh0LXBsYXRpbmEvNDAgdHJhY2tpbmctd2lkZXN0IHVwcGVyY2FzZSBtdC0yXCI+QmVtLXZpbmRvIGFvIGNlbnRybyBkZSBjb21hbmRvIFRlbGVNYXNzYTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWR9XG4gICAgICAgICAgZGlzYWJsZWQ9e2lzRG93bmxvYWRpbmd9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNiBweS0zIHRleHQteHNcIlxuICAgICAgICA+XG4gICAgICAgICAgPERvd25sb2FkIHNpemU9ezE2fSBjbGFzc05hbWU9e2lzRG93bmxvYWRpbmcgPyAnYW5pbWF0ZS1ib3VuY2UnIDogJyd9IC8+XG4gICAgICAgICAge2lzRG93bmxvYWRpbmcgPyAnUHJlcGFyYW5kbyBaSVAuLi4nIDogJ0JhaXhhciBTaXRlIG5vIFpJUCd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxtb3Rpb24uZGl2IFxuICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC04XCJcbiAgICAgID5cbiAgICAgICAge21ldHJpY3MubWFwKChtZXRyaWMsIGluZGV4KSA9PiAoXG4gICAgICAgICAgPG1vdGlvbi5kaXYgXG4gICAgICAgICAgICBrZXk9e2luZGV4fSBcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogaW5kZXggKiAwLjA4IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIHAtOCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBoLVsyMDBweF0gcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZXJpZiB0ZXh0LTV4bCBmb250LWJsYWNrIGJnLVtsaW5lYXItZ3JhZGllbnQodG9fYm90dG9tLCNENEFGMzcsI0Y1RDc2RSldIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+e21ldHJpYy52YWx1ZX08L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1bMTFweF0gdGV4dC1wbGF0aW5hIHRyYWNraW5nLVswLjE1ZW1dIG10LTFcIj57bWV0cmljLnRpdGxlLnRvVXBwZXJDYXNlKCl9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctZ29sZC81IHJvdW5kZWQtWzEwcHhdXCI+XG4gICAgICAgICAgICAgICAgPG1ldHJpYy5pY29uIGNsYXNzTmFtZT1cInN0cm9rZS1nb2xkXCIgc2l6ZT17MjR9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00IGJvcmRlci10IGJvcmRlci1nb2xkLzEwIHB0LTRcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1lbWVyYWxkIHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgPEFycm93VXBSaWdodCBzaXplPXsxNH0gY2xhc3NOYW1lPVwibXItMVwiIC8+IHttZXRyaWMudHJlbmR9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgdy1mdWxsIGgtWzJweF0gYmctW2xpbmVhci1ncmFkaWVudCg5MGRlZyx0cmFuc3BhcmVudCwjRDRBRjM3LHRyYW5zcGFyZW50KV1cIiAvPlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L21vdGlvbi5kaXY+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtOFwiPlxuICAgICAgICA8bW90aW9uLmRpdiBcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC4zIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMiBnbGFzcy1jYXJkIHAtOFwiXG4gICAgICAgID5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1zZXJpZiB0ZXh0LTJ4bCB0ZXh0LWNoYW1wYWduZSBtYi02XCI+QXRpdmlkYWRlIFJlY2VudGU8L2gyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NCBiZy1iZy0xLzUwIHJvdW5kZWQtWzE2cHhdIGJvcmRlciBib3JkZXItZ29sZC8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXBsYXRpbmEvMzAgZm9udC1tb25vIHRleHQtc21cIj5cbiAgICAgICAgICAgIFtHcsOhZmljbyBkZSBBdGl2aWRhZGUgLSBSZWNoYXJ0c11cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgIDxtb3Rpb24uZGl2IFxuICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjQgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIHAtOCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ29sZC8xMCByb3VuZGVkLWZ1bGxcIj5cbiAgICAgICAgICAgIDxTaGllbGRDaGVjayBzaXplPXs0MH0gY2xhc3NOYW1lPVwidGV4dC1nb2xkXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZXJpZiB0ZXh0LXhsIHRleHQtY2hhbXBhZ25lXCI+U2VndXJhbsOnYSAmIEJhY2t1cDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1wbGF0aW5hLzYwIHRleHQteHMgZm9udC1zYW5zIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgU2V1cyBkYWRvcyBzw6NvIGFybWF6ZW5hZG9zIGxvY2FsbWVudGUuIFJlY29tZW5kYW1vcyBiYWl4YXIgbyBjw7NkaWdvIGRvIHNpdGUgcmVndWxhcm1lbnRlIHBhcmEgbWFudGVyIHVtYSBjw7NwaWEgZGUgc2VndXJhbsOnYSBlbSBzZXUgZGlzcG9zaXRpdm8uXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlRG93bmxvYWR9IGNsYXNzTmFtZT1cInRleHQtZ29sZCB0ZXh0LVsxMHB4XSBmb250LWNpbnplbCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgSW5pY2lhciBCYWNrdXAgQWdvcmFcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiJBQWdDVTtBQWhDVixTQUFTLEtBQUssZUFBZSxPQUFtQixjQUFjLFVBQVUsbUJBQW1CO0FBQzNGLFNBQVMsY0FBYztBQUN2QixTQUFTLHVCQUF1QjtBQUVoQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLGdCQUFnQjtBQUV6Qix3QkFBd0IsWUFBWTtBQUNsQyxRQUFNLENBQUMsSUFBSSxJQUFJLGdCQUEyQixRQUFRLENBQUMsQ0FBQztBQUNwRCxRQUFNLENBQUMsUUFBUSxJQUFJLGdCQUEyQixZQUFZLENBQUMsQ0FBQztBQUM1RCxRQUFNLENBQUMsT0FBTyxJQUFJLGdCQUEwQixXQUFXLENBQUMsQ0FBQztBQUN6RCxRQUFNLENBQUMsZUFBZSxnQkFBZ0IsSUFBSSxTQUFTLEtBQUs7QUFFeEQsUUFBTSxpQkFBaUIsWUFBWTtBQUNqQyxxQkFBaUIsSUFBSTtBQUNyQixRQUFJO0FBQ0YsWUFBTSxtQkFBbUI7QUFBQSxJQUMzQixVQUFFO0FBQ0EsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFVBQVU7QUFBQSxJQUNkLEVBQUUsT0FBTyxjQUFjLE9BQU8sS0FBSyxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUs7QUFBQSxJQUNsRSxFQUFFLE9BQU8sbUJBQW1CLE9BQU8sU0FBUyxRQUFRLE1BQU0sZUFBZSxPQUFPLEtBQUs7QUFBQSxJQUNyRixFQUFFLE9BQU8sa0JBQWtCLE9BQU8sUUFBUSxRQUFRLE1BQU0sT0FBTyxPQUFPLEtBQUs7QUFBQSxFQUM3RTtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNDQUFxQywyQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RDtBQUFBLFFBQzlELHVCQUFDLE9BQUUsV0FBVSwwRUFBeUUsd0RBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEg7QUFBQSxXQUZoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFlBQVMsTUFBTSxJQUFJLFdBQVcsZ0JBQWdCLG1CQUFtQixNQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3JFLGdCQUFnQixzQkFBc0I7QUFBQTtBQUFBO0FBQUEsUUFOekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBRUE7QUFBQSxNQUFDLE9BQU87QUFBQSxNQUFQO0FBQUEsUUFDQyxTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRztBQUFBLFFBQzdCLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQUEsUUFDNUIsV0FBVTtBQUFBLFFBRVQsa0JBQVEsSUFBSSxDQUFDLFFBQVEsVUFDcEI7QUFBQSxVQUFDLE9BQU87QUFBQSxVQUFQO0FBQUEsWUFFQyxTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRztBQUFBLFlBQzdCLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQUEsWUFDNUIsWUFBWSxFQUFFLE9BQU8sUUFBUSxLQUFLO0FBQUEsWUFDbEMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLGdIQUFnSCxpQkFBTyxTQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwSTtBQUFBLGtCQUMxSSx1QkFBQyxPQUFFLFdBQVUsK0RBQStELGlCQUFPLE1BQU0sWUFBWSxLQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RztBQUFBLHFCQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLE9BQU8sTUFBUCxFQUFZLFdBQVUsZUFBYyxNQUFNLE1BQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsVUFBSyxXQUFVLG9EQUNkO0FBQUEsdUNBQUMsZ0JBQWEsTUFBTSxJQUFJLFdBQVUsVUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFBRTtBQUFBLGdCQUFFLE9BQU87QUFBQSxtQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5R0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxSDtBQUFBO0FBQUE7QUFBQSxVQXBCaEg7QUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQkEsQ0FDRDtBQUFBO0FBQUEsTUE3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOEJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLFFBQUMsT0FBTztBQUFBLFFBQVA7QUFBQSxVQUNDLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxHQUFHO0FBQUEsVUFDN0IsU0FBUyxFQUFFLFNBQVMsR0FBRyxHQUFHLEVBQUU7QUFBQSxVQUM1QixZQUFZLEVBQUUsT0FBTyxJQUFJO0FBQUEsVUFDekIsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMkNBQTBDLGlDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RTtBQUFBLFlBQ3pFLHVCQUFDLFNBQUksV0FBVSwySEFBMEgsaURBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBO0FBQUEsUUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BRUE7QUFBQSxRQUFDLE9BQU87QUFBQSxRQUFQO0FBQUEsVUFDQyxTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRztBQUFBLFVBQzdCLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFO0FBQUEsVUFDNUIsWUFBWSxFQUFFLE9BQU8sSUFBSTtBQUFBLFVBQ3pCLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLGVBQVksTUFBTSxJQUFJLFdBQVUsZUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLHFDQUFvQyxrQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0U7QUFBQSxZQUNwRSx1QkFBQyxPQUFFLFdBQVUscURBQW9ELCtKQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxZQUFPLFNBQVMsZ0JBQWdCLFdBQVUsK0VBQThFLG9DQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQTtBQUFBLFFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ0JBO0FBQUEsU0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFSjsiLCJuYW1lcyI6W119