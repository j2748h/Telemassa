import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];
import { useLocalStorage } from "/src/hooks/useStorage.ts";
import { Trash2, Plus, LayoutGrid, List, Download, Edit2, Upload, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import Popup from "/src/components/ui/Popup.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
export default function ClientManager() {
  const [clients, setClients] = useLocalStorage("clients", []);
  const [viewMode, setViewMode] = useLocalStorage("client_view", "grid");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isHelpPopupOpen, setIsHelpPopupOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [formData, setFormData] = useState({ name: "", username: "", uid: "", tags: "" });
  const { addToast } = useToast();
  const fileInputRef = useRef(null);
  const mergeClients = (existingClients, newClient) => {
    const existingIndex = existingClients.findIndex((c) => c.uid === newClient.uid);
    if (existingIndex > -1) {
      const updatedClients = [...existingClients];
      updatedClients[existingIndex] = {
        ...updatedClients[existingIndex],
        ...newClient,
        tags: Array.from(/* @__PURE__ */ new Set([...updatedClients[existingIndex].tags, ...newClient.tags])),
        lastActive: (/* @__PURE__ */ new Date()).toISOString()
      };
      return updatedClients;
    }
    return [...existingClients, { ...newClient, id: Date.now().toString() + Math.random(), lastActive: (/* @__PURE__ */ new Date()).toISOString() }];
  };
  const handleSave = () => {
    const tagsArray = formData.tags.split(",").map((t) => t.trim()).filter((t) => t !== "");
    if (editingClient) {
      setClients(clients.map((c) => c.id === editingClient.id ? { ...c, ...formData, tags: tagsArray } : c));
      addToast({ type: "success", title: "Cliente Atualizado", message: "Dados do cliente atualizados." });
    } else {
      const newClient = { name: formData.name, username: formData.username, uid: formData.uid, tags: tagsArray };
      setClients(mergeClients(clients, newClient));
      addToast({ type: "success", title: "Cliente Salvo", message: "Cliente adicionado ou mesclado com sucesso." });
    }
    setIsPopupOpen(false);
    setEditingClient(null);
    setFormData({ name: "", username: "", uid: "", tags: "" });
  };
  const openEdit = (client) => {
    setEditingClient(client);
    setFormData({ name: client.name, username: client.username, uid: client.uid, tags: client.tags.join(", ") });
    setIsPopupOpen(true);
  };
  const exportData = () => {
    const csv = "Nome,Username,UID,Tags\n" + clients.map((c) => `${c.name},${c.username},${c.uid},${c.tags.join(";")}`).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `telemassa_clientes_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`;
    a.click();
  };
  const importData = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result;
      const lines = text.split("\n").slice(1);
      let updatedClients = [...clients];
      let importedCount = 0;
      lines.filter((line) => line.trim()).forEach((line) => {
        const [name, username, uid, tags] = line.split(",");
        if (uid) {
          const newClient = { name, username, uid, tags: tags ? tags.split(";") : [] };
          updatedClients = mergeClients(updatedClients, newClient);
          importedCount++;
        }
      });
      setClients(updatedClients);
      addToast({ type: "success", title: "Importação Concluída", message: `${importedCount} clientes processados e mesclados.` });
    };
    reader.readAsText(file);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-12", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "font-serif text-4xl text-champagne", children: "Clientes" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 92,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV("input", { type: "file", ref: fileInputRef, onChange: importData, accept: ".csv", className: "hidden" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 94,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsHelpPopupOpen(true), className: "flex items-center gap-2 px-5 py-3 bg-bg-2 border border-gold/20 rounded-full text-platina hover:border-gold transition-all", children: [
          /* @__PURE__ */ jsxDEV(HelpCircle, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 95,
            columnNumber: 195
          }, this),
          " Ajuda"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 95,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setViewMode(viewMode === "grid" ? "table" : "grid"), className: "flex items-center gap-2 px-5 py-3 bg-bg-2 border border-gold/20 rounded-full text-platina hover:border-gold transition-all", children: [
          viewMode === "grid" ? /* @__PURE__ */ jsxDEV(List, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 96,
            columnNumber: 245
          }, this) : /* @__PURE__ */ jsxDEV(LayoutGrid, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 96,
            columnNumber: 265
          }, this),
          " ",
          viewMode === "grid" ? "Lista" : "Grade"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 96,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => fileInputRef.current?.click(), className: "flex items-center gap-2 px-5 py-3 bg-bg-2 border border-gold/20 rounded-full text-platina hover:border-gold transition-all", children: [
          /* @__PURE__ */ jsxDEV(Upload, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 97,
            columnNumber: 200
          }, this),
          " Importar"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 97,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: exportData, className: "flex items-center gap-2 px-5 py-3 bg-bg-2 border border-gold/20 rounded-full text-platina hover:border-gold transition-all", children: [
          /* @__PURE__ */ jsxDEV(Download, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 98,
            columnNumber: 175
          }, this),
          " Baixar"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsPopupOpen(true), className: "btn-primary flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Plus, { size: 18 }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 99,
            columnNumber: 104
          }, this),
          " Adicionar"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 99,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 93,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    viewMode === "grid" ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8", children: clients.map((c) => /* @__PURE__ */ jsxDEV("div", { className: "glass-card p-8 space-y-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-serif text-xl text-champagne", children: c.name }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 107,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: (c.tags || []).map((t) => /* @__PURE__ */ jsxDEV("span", { className: "px-4 py-1 bg-gold/10 text-gold rounded-full text-[10px] font-cinzel tracking-widest uppercase", children: t }, t, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 109,
        columnNumber: 42
      }, this)) }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 108,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 pt-4 border-t border-gold/10", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => openEdit(c), className: "text-gold hover:text-gold-light transition-colors", children: /* @__PURE__ */ jsxDEV(Edit2, { size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 112,
          columnNumber: 115
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 112,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setClients(clients.filter((cl) => cl.id !== c.id)), className: "text-ruby hover:text-ruby/80 transition-colors", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 113,
          columnNumber: 149
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 113,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 111,
        columnNumber: 15
      }, this)
    ] }, c.id, true, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 106,
      columnNumber: 13
    }, this)) }, void 0, false, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 104,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "glass-card p-8", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-champagne font-sans text-sm", children: [
      /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gold/10 text-platina/60 text-left font-cinzel text-[11px] uppercase tracking-widest", children: [
        /* @__PURE__ */ jsxDEV("th", { children: "Nome" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 121,
          columnNumber: 136
        }, this),
        /* @__PURE__ */ jsxDEV("th", { children: "Username" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 121,
          columnNumber: 149
        }, this),
        /* @__PURE__ */ jsxDEV("th", { children: "Tags" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 121,
          columnNumber: 166
        }, this),
        /* @__PURE__ */ jsxDEV("th", { children: "Ações" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 121,
          columnNumber: 179
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 121,
        columnNumber: 20
      }, this) }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 121,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { children: clients.map((c) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-gold/5 hover:bg-gold/5 transition-colors", children: [
        /* @__PURE__ */ jsxDEV("td", { children: c.name }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 122
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: c.username }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 139
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: (c.tags || []).join(", ") }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 160
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setClients(clients.filter((cl) => cl.id !== c.id)), className: "text-ruby", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 16 }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 295
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 200
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 122,
          columnNumber: 196
        }, this)
      ] }, c.id, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 122,
        columnNumber: 38
      }, this)) }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 122,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 120,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 119,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Popup, { isOpen: isPopupOpen, onClose: () => {
      setIsPopupOpen(false);
      setEditingClient(null);
      setFormData({ name: "", username: "", uid: "", tags: "" });
    }, title: editingClient ? "Editar Cliente" : "Adicionar Cliente", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Nome", value: formData.name, onChange: (e) => setFormData({ ...formData, name: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 129,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Username", value: formData.username, onChange: (e) => setFormData({ ...formData, username: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 130,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "UID", value: formData.uid, onChange: (e) => setFormData({ ...formData, uid: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 131,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Tags (separadas por vírgula)", value: formData.tags, onChange: (e) => setFormData({ ...formData, tags: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 132,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleSave, className: "btn-primary w-full", children: "Salvar" }, void 0, false, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 133,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 128,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Popup, { isOpen: isHelpPopupOpen, onClose: () => setIsHelpPopupOpen(false), title: "Como Gerenciar Clientes", subtitle: "Entenda como o sistema funciona", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 text-champagne font-sans text-sm", children: [
      /* @__PURE__ */ jsxDEV("section", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-cinzel text-gold mb-2", children: "Adicionando Clientes" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 140,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: 'Você pode adicionar clientes manualmente clicando no botão "Adicionar" ou importar uma lista completa via arquivo CSV.' }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 141,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 139,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("section", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-cinzel text-gold mb-2", children: "Formato de Arquivo (CSV)" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 144,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "O arquivo deve conter as colunas: ",
          /* @__PURE__ */ jsxDEV("strong", { children: "Nome,Username,UID,Tags" }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 145,
            columnNumber: 50
          }, this),
          ". As tags devem ser separadas por ponto e vírgula (;) dentro do arquivo."
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 145,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 143,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("section", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-cinzel text-gold mb-2", children: "Detecção de Duplicatas" }, void 0, false, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "O sistema detecta automaticamente clientes duplicados usando o ",
          /* @__PURE__ */ jsxDEV("strong", { children: "UID" }, void 0, false, {
            fileName: "/app/applet/src/components/ClientManager.tsx",
            lineNumber: 149,
            columnNumber: 79
          }, this),
          " como identificador único. Se um cliente com o mesmo UID for importado ou adicionado, suas informações serão mescladas e as tags serão unidas, evitando duplicidade."
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ClientManager.tsx",
          lineNumber: 149,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/ClientManager.tsx",
        lineNumber: 147,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 138,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/ClientManager.tsx",
      lineNumber: 137,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/ClientManager.tsx",
    lineNumber: 90,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNsaWVudE1hbmFnZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTG9jYWxTdG9yYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlU3RvcmFnZSc7XG5pbXBvcnQgeyBDbGllbnQgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBUcmFzaDIsIFBsdXMsIExheW91dEdyaWQsIExpc3QsIERvd25sb2FkLCBFZGl0MiwgVXBsb2FkLCBIZWxwQ2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBQb3B1cCBmcm9tICcuL3VpL1BvcHVwJztcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSAnLi91aS9Ub2FzdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENsaWVudE1hbmFnZXIoKSB7XG4gIGNvbnN0IFtjbGllbnRzLCBzZXRDbGllbnRzXSA9IHVzZUxvY2FsU3RvcmFnZTxDbGllbnRbXT4oJ2NsaWVudHMnLCBbXSk7XG4gIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlTG9jYWxTdG9yYWdlPCdncmlkJyB8ICd0YWJsZSc+KCdjbGllbnRfdmlldycsICdncmlkJyk7XG4gIGNvbnN0IFtpc1BvcHVwT3Blbiwgc2V0SXNQb3B1cE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNIZWxwUG9wdXBPcGVuLCBzZXRJc0hlbHBQb3B1cE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdGluZ0NsaWVudCwgc2V0RWRpdGluZ0NsaWVudF0gPSB1c2VTdGF0ZTxDbGllbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7IG5hbWU6ICcnLCB1c2VybmFtZTogJycsIHVpZDogJycsIHRhZ3M6ICcnIH0pO1xuICBjb25zdCB7IGFkZFRvYXN0IH0gPSB1c2VUb2FzdCgpO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG5cbiAgY29uc3QgbWVyZ2VDbGllbnRzID0gKGV4aXN0aW5nQ2xpZW50czogQ2xpZW50W10sIG5ld0NsaWVudDogT21pdDxDbGllbnQsICdpZCcgfCAnbGFzdEFjdGl2ZSc+KTogQ2xpZW50W10gPT4ge1xuICAgIGNvbnN0IGV4aXN0aW5nSW5kZXggPSBleGlzdGluZ0NsaWVudHMuZmluZEluZGV4KGMgPT4gYy51aWQgPT09IG5ld0NsaWVudC51aWQpO1xuICAgIGlmIChleGlzdGluZ0luZGV4ID4gLTEpIHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRDbGllbnRzID0gWy4uLmV4aXN0aW5nQ2xpZW50c107XG4gICAgICB1cGRhdGVkQ2xpZW50c1tleGlzdGluZ0luZGV4XSA9IHtcbiAgICAgICAgLi4udXBkYXRlZENsaWVudHNbZXhpc3RpbmdJbmRleF0sXG4gICAgICAgIC4uLm5ld0NsaWVudCxcbiAgICAgICAgdGFnczogQXJyYXkuZnJvbShuZXcgU2V0KFsuLi51cGRhdGVkQ2xpZW50c1tleGlzdGluZ0luZGV4XS50YWdzLCAuLi5uZXdDbGllbnQudGFnc10pKSxcbiAgICAgICAgbGFzdEFjdGl2ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICB9O1xuICAgICAgcmV0dXJuIHVwZGF0ZWRDbGllbnRzO1xuICAgIH1cbiAgICByZXR1cm4gWy4uLmV4aXN0aW5nQ2xpZW50cywgeyAuLi5uZXdDbGllbnQsIGlkOiBEYXRlLm5vdygpLnRvU3RyaW5nKCkgKyBNYXRoLnJhbmRvbSgpLCBsYXN0QWN0aXZlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfV07XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9ICgpID0+IHtcbiAgICBjb25zdCB0YWdzQXJyYXkgPSBmb3JtRGF0YS50YWdzLnNwbGl0KCcsJykubWFwKHQgPT4gdC50cmltKCkpLmZpbHRlcih0ID0+IHQgIT09ICcnKTtcbiAgICBpZiAoZWRpdGluZ0NsaWVudCkge1xuICAgICAgc2V0Q2xpZW50cyhjbGllbnRzLm1hcChjID0+IGMuaWQgPT09IGVkaXRpbmdDbGllbnQuaWQgPyB7IC4uLmMsIC4uLmZvcm1EYXRhLCB0YWdzOiB0YWdzQXJyYXkgfSA6IGMpKTtcbiAgICAgIGFkZFRvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0NsaWVudGUgQXR1YWxpemFkbycsIG1lc3NhZ2U6ICdEYWRvcyBkbyBjbGllbnRlIGF0dWFsaXphZG9zLicgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG5ld0NsaWVudCA9IHsgbmFtZTogZm9ybURhdGEubmFtZSwgdXNlcm5hbWU6IGZvcm1EYXRhLnVzZXJuYW1lLCB1aWQ6IGZvcm1EYXRhLnVpZCwgdGFnczogdGFnc0FycmF5IH07XG4gICAgICBzZXRDbGllbnRzKG1lcmdlQ2xpZW50cyhjbGllbnRzLCBuZXdDbGllbnQpKTtcbiAgICAgIGFkZFRvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0NsaWVudGUgU2Fsdm8nLCBtZXNzYWdlOiAnQ2xpZW50ZSBhZGljaW9uYWRvIG91IG1lc2NsYWRvIGNvbSBzdWNlc3NvLicgfSk7XG4gICAgfVxuICAgIHNldElzUG9wdXBPcGVuKGZhbHNlKTtcbiAgICBzZXRFZGl0aW5nQ2xpZW50KG51bGwpO1xuICAgIHNldEZvcm1EYXRhKHsgbmFtZTogJycsIHVzZXJuYW1lOiAnJywgdWlkOiAnJywgdGFnczogJycgfSk7XG4gIH07XG5cbiAgY29uc3Qgb3BlbkVkaXQgPSAoY2xpZW50OiBDbGllbnQpID0+IHtcbiAgICBzZXRFZGl0aW5nQ2xpZW50KGNsaWVudCk7XG4gICAgc2V0Rm9ybURhdGEoeyBuYW1lOiBjbGllbnQubmFtZSwgdXNlcm5hbWU6IGNsaWVudC51c2VybmFtZSwgdWlkOiBjbGllbnQudWlkLCB0YWdzOiBjbGllbnQudGFncy5qb2luKCcsICcpIH0pO1xuICAgIHNldElzUG9wdXBPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGV4cG9ydERhdGEgPSAoKSA9PiB7XG4gICAgY29uc3QgY3N2ID0gXCJOb21lLFVzZXJuYW1lLFVJRCxUYWdzXFxuXCIgKyBjbGllbnRzLm1hcChjID0+IGAke2MubmFtZX0sJHtjLnVzZXJuYW1lfSwke2MudWlkfSwke2MudGFncy5qb2luKCc7Jyl9YCkuam9pbignXFxuJyk7XG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZdLCB7IHR5cGU6ICd0ZXh0L2NzdicgfSk7XG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gYHRlbGVtYXNzYV9jbGllbnRlc18ke25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdfS5jc3ZgO1xuICAgIGEuY2xpY2soKTtcbiAgfTtcblxuICBjb25zdCBpbXBvcnREYXRhID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHRleHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoJ1xcbicpLnNsaWNlKDEpO1xuICAgICAgbGV0IHVwZGF0ZWRDbGllbnRzID0gWy4uLmNsaWVudHNdO1xuICAgICAgbGV0IGltcG9ydGVkQ291bnQgPSAwO1xuICAgICAgXG4gICAgICBsaW5lcy5maWx0ZXIobGluZSA9PiBsaW5lLnRyaW0oKSkuZm9yRWFjaChsaW5lID0+IHtcbiAgICAgICAgY29uc3QgW25hbWUsIHVzZXJuYW1lLCB1aWQsIHRhZ3NdID0gbGluZS5zcGxpdCgnLCcpO1xuICAgICAgICBpZiAodWlkKSB7XG4gICAgICAgICAgY29uc3QgbmV3Q2xpZW50ID0geyBuYW1lLCB1c2VybmFtZSwgdWlkLCB0YWdzOiB0YWdzID8gdGFncy5zcGxpdCgnOycpIDogW10gfTtcbiAgICAgICAgICB1cGRhdGVkQ2xpZW50cyA9IG1lcmdlQ2xpZW50cyh1cGRhdGVkQ2xpZW50cywgbmV3Q2xpZW50KTtcbiAgICAgICAgICBpbXBvcnRlZENvdW50Kys7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgc2V0Q2xpZW50cyh1cGRhdGVkQ2xpZW50cyk7XG4gICAgICBhZGRUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdJbXBvcnRhw6fDo28gQ29uY2x1w61kYScsIG1lc3NhZ2U6IGAke2ltcG9ydGVkQ291bnR9IGNsaWVudGVzIHByb2Nlc3NhZG9zIGUgbWVzY2xhZG9zLmAgfSk7XG4gICAgfTtcbiAgICByZWFkZXIucmVhZEFzVGV4dChmaWxlKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xMlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VyaWYgdGV4dC00eGwgdGV4dC1jaGFtcGFnbmVcIj5DbGllbnRlczwvaDI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIHJlZj17ZmlsZUlucHV0UmVmfSBvbkNoYW5nZT17aW1wb3J0RGF0YX0gYWNjZXB0PVwiLmNzdlwiIGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRJc0hlbHBQb3B1cE9wZW4odHJ1ZSl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTUgcHktMyBiZy1iZy0yIGJvcmRlciBib3JkZXItZ29sZC8yMCByb3VuZGVkLWZ1bGwgdGV4dC1wbGF0aW5hIGhvdmVyOmJvcmRlci1nb2xkIHRyYW5zaXRpb24tYWxsXCI+PEhlbHBDaXJjbGUgc2l6ZT17MTh9IC8+IEFqdWRhPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZSh2aWV3TW9kZSA9PT0gJ2dyaWQnID8gJ3RhYmxlJyA6ICdncmlkJyl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTUgcHktMyBiZy1iZy0yIGJvcmRlciBib3JkZXItZ29sZC8yMCByb3VuZGVkLWZ1bGwgdGV4dC1wbGF0aW5hIGhvdmVyOmJvcmRlci1nb2xkIHRyYW5zaXRpb24tYWxsXCI+e3ZpZXdNb2RlID09PSAnZ3JpZCcgPyA8TGlzdCBzaXplPXsxOH0vPiA6IDxMYXlvdXRHcmlkIHNpemU9ezE4fSAvPn0ge3ZpZXdNb2RlID09PSAnZ3JpZCcgPyAnTGlzdGEnIDogJ0dyYWRlJ308L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC01IHB5LTMgYmctYmctMiBib3JkZXIgYm9yZGVyLWdvbGQvMjAgcm91bmRlZC1mdWxsIHRleHQtcGxhdGluYSBob3Zlcjpib3JkZXItZ29sZCB0cmFuc2l0aW9uLWFsbFwiPjxVcGxvYWQgc2l6ZT17MTh9IC8+IEltcG9ydGFyPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtleHBvcnREYXRhfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC01IHB5LTMgYmctYmctMiBib3JkZXIgYm9yZGVyLWdvbGQvMjAgcm91bmRlZC1mdWxsIHRleHQtcGxhdGluYSBob3Zlcjpib3JkZXItZ29sZCB0cmFuc2l0aW9uLWFsbFwiPjxEb3dubG9hZCBzaXplPXsxOH0gLz4gQmFpeGFyPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRJc1BvcHVwT3Blbih0cnVlKX0gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48UGx1cyBzaXplPXsxOH0gLz4gQWRpY2lvbmFyPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHt2aWV3TW9kZSA9PT0gJ2dyaWQnID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLThcIj5cbiAgICAgICAgICB7Y2xpZW50cy5tYXAoYyA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17Yy5pZH0gY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCBwLTggc3BhY2UteS02XCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VyaWYgdGV4dC14bCB0ZXh0LWNoYW1wYWduZVwiPntjLm5hbWV9PC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgeyhjLnRhZ3MgfHwgW10pLm1hcCh0ID0+IDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwicHgtNCBweS0xIGJnLWdvbGQvMTAgdGV4dC1nb2xkIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWNpbnplbCB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlXCI+e3R9PC9zcGFuPil9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItZ29sZC8xMFwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb3BlbkVkaXQoYyl9IGNsYXNzTmFtZT1cInRleHQtZ29sZCBob3Zlcjp0ZXh0LWdvbGQtbGlnaHQgdHJhbnNpdGlvbi1jb2xvcnNcIj48RWRpdDIgc2l6ZT17MTh9IC8+PC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRDbGllbnRzKGNsaWVudHMuZmlsdGVyKGNsID0+IGNsLmlkICE9PSBjLmlkKSl9IGNsYXNzTmFtZT1cInRleHQtcnVieSBob3Zlcjp0ZXh0LXJ1YnkvODAgdHJhbnNpdGlvbi1jb2xvcnNcIj48VHJhc2gyIHNpemU9ezE4fSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCBwLThcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2hhbXBhZ25lIGZvbnQtc2FucyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICA8dGhlYWQ+PHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1nb2xkLzEwIHRleHQtcGxhdGluYS82MCB0ZXh0LWxlZnQgZm9udC1jaW56ZWwgdGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPjx0aD5Ob21lPC90aD48dGg+VXNlcm5hbWU8L3RoPjx0aD5UYWdzPC90aD48dGg+QcOnw7VlczwvdGg+PC90cj48L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PntjbGllbnRzLm1hcChjID0+IDx0ciBrZXk9e2MuaWR9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1nb2xkLzUgaG92ZXI6YmctZ29sZC81IHRyYW5zaXRpb24tY29sb3JzXCI+PHRkPntjLm5hbWV9PC90ZD48dGQ+e2MudXNlcm5hbWV9PC90ZD48dGQ+eyhjLnRhZ3MgfHwgW10pLmpvaW4oJywgJyl9PC90ZD48dGQ+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRDbGllbnRzKGNsaWVudHMuZmlsdGVyKGNsID0+IGNsLmlkICE9PSBjLmlkKSl9IGNsYXNzTmFtZT1cInRleHQtcnVieVwiPjxUcmFzaDIgc2l6ZT17MTZ9IC8+PC9idXR0b24+PC90ZD48L3RyPil9PC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxQb3B1cCBpc09wZW49e2lzUG9wdXBPcGVufSBvbkNsb3NlPXsoKSA9PiB7IHNldElzUG9wdXBPcGVuKGZhbHNlKTsgc2V0RWRpdGluZ0NsaWVudChudWxsKTsgc2V0Rm9ybURhdGEoeyBuYW1lOiAnJywgdXNlcm5hbWU6ICcnLCB1aWQ6ICcnLCB0YWdzOiAnJyB9KTsgfX0gdGl0bGU9e2VkaXRpbmdDbGllbnQgPyBcIkVkaXRhciBDbGllbnRlXCIgOiBcIkFkaWNpb25hciBDbGllbnRlXCJ9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTm9tZVwiIHZhbHVlPXtmb3JtRGF0YS5uYW1lfSBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YSh7Li4uZm9ybURhdGEsIG5hbWU6IGUudGFyZ2V0LnZhbHVlfSl9IGNsYXNzTmFtZT1cInctZnVsbFwiIC8+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJVc2VybmFtZVwiIHZhbHVlPXtmb3JtRGF0YS51c2VybmFtZX0gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCB1c2VybmFtZTogZS50YXJnZXQudmFsdWV9KX0gY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIlVJRFwiIHZhbHVlPXtmb3JtRGF0YS51aWR9IG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHsuLi5mb3JtRGF0YSwgdWlkOiBlLnRhcmdldC52YWx1ZX0pfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiAvPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiVGFncyAoc2VwYXJhZGFzIHBvciB2w61yZ3VsYSlcIiB2YWx1ZT17Zm9ybURhdGEudGFnc30gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCB0YWdzOiBlLnRhcmdldC52YWx1ZX0pfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiAvPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlU2F2ZX0gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgdy1mdWxsXCI+U2FsdmFyPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Qb3B1cD5cblxuICAgICAgPFBvcHVwIGlzT3Blbj17aXNIZWxwUG9wdXBPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc0hlbHBQb3B1cE9wZW4oZmFsc2UpfSB0aXRsZT1cIkNvbW8gR2VyZW5jaWFyIENsaWVudGVzXCIgc3VidGl0bGU9XCJFbnRlbmRhIGNvbW8gbyBzaXN0ZW1hIGZ1bmNpb25hXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IHRleHQtY2hhbXBhZ25lIGZvbnQtc2FucyB0ZXh0LXNtXCI+XG4gICAgICAgICAgPHNlY3Rpb24+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1nb2xkIG1iLTJcIj5BZGljaW9uYW5kbyBDbGllbnRlczwvaDM+XG4gICAgICAgICAgICA8cD5Wb2PDqiBwb2RlIGFkaWNpb25hciBjbGllbnRlcyBtYW51YWxtZW50ZSBjbGljYW5kbyBubyBib3TDo28gXCJBZGljaW9uYXJcIiBvdSBpbXBvcnRhciB1bWEgbGlzdGEgY29tcGxldGEgdmlhIGFycXVpdm8gQ1NWLjwvcD5cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgPHNlY3Rpb24+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1nb2xkIG1iLTJcIj5Gb3JtYXRvIGRlIEFycXVpdm8gKENTVik8L2gzPlxuICAgICAgICAgICAgPHA+TyBhcnF1aXZvIGRldmUgY29udGVyIGFzIGNvbHVuYXM6IDxzdHJvbmc+Tm9tZSxVc2VybmFtZSxVSUQsVGFnczwvc3Ryb25nPi4gQXMgdGFncyBkZXZlbSBzZXIgc2VwYXJhZGFzIHBvciBwb250byBlIHbDrXJndWxhICg7KSBkZW50cm8gZG8gYXJxdWl2by48L3A+XG4gICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDxzZWN0aW9uPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtY2luemVsIHRleHQtZ29sZCBtYi0yXCI+RGV0ZWPDp8OjbyBkZSBEdXBsaWNhdGFzPC9oMz5cbiAgICAgICAgICAgIDxwPk8gc2lzdGVtYSBkZXRlY3RhIGF1dG9tYXRpY2FtZW50ZSBjbGllbnRlcyBkdXBsaWNhZG9zIHVzYW5kbyBvIDxzdHJvbmc+VUlEPC9zdHJvbmc+IGNvbW8gaWRlbnRpZmljYWRvciDDum5pY28uIFNlIHVtIGNsaWVudGUgY29tIG8gbWVzbW8gVUlEIGZvciBpbXBvcnRhZG8gb3UgYWRpY2lvbmFkbywgc3VhcyBpbmZvcm1hw6fDtWVzIHNlcsOjbyBtZXNjbGFkYXMgZSBhcyB0YWdzIHNlcsOjbyB1bmlkYXMsIGV2aXRhbmRvIGR1cGxpY2lkYWRlLjwvcD5cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Qb3B1cD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBMkZRO0FBM0ZSLFNBQWdCLFVBQVUsY0FBYztBQUN4QyxTQUFTLHVCQUF1QjtBQUVoQyxTQUFTLFFBQVEsTUFBTSxZQUFZLE1BQU0sVUFBVSxPQUFPLFFBQVEsa0JBQWtCO0FBQ3BGLE9BQU8sV0FBVztBQUNsQixTQUFTLGdCQUFnQjtBQUV6Qix3QkFBd0IsZ0JBQWdCO0FBQ3RDLFFBQU0sQ0FBQyxTQUFTLFVBQVUsSUFBSSxnQkFBMEIsV0FBVyxDQUFDLENBQUM7QUFDckUsUUFBTSxDQUFDLFVBQVUsV0FBVyxJQUFJLGdCQUFrQyxlQUFlLE1BQU07QUFDdkYsUUFBTSxDQUFDLGFBQWEsY0FBYyxJQUFJLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUMsaUJBQWlCLGtCQUFrQixJQUFJLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMsZUFBZSxnQkFBZ0IsSUFBSSxTQUF3QixJQUFJO0FBQ3RFLFFBQU0sQ0FBQyxVQUFVLFdBQVcsSUFBSSxTQUFTLEVBQUUsTUFBTSxJQUFJLFVBQVUsSUFBSSxLQUFLLElBQUksTUFBTSxHQUFHLENBQUM7QUFDdEYsUUFBTSxFQUFFLFNBQVMsSUFBSSxTQUFTO0FBQzlCLFFBQU0sZUFBZSxPQUF5QixJQUFJO0FBRWxELFFBQU0sZUFBZSxDQUFDLGlCQUEyQixjQUEyRDtBQUMxRyxVQUFNLGdCQUFnQixnQkFBZ0IsVUFBVSxPQUFLLEVBQUUsUUFBUSxVQUFVLEdBQUc7QUFDNUUsUUFBSSxnQkFBZ0IsSUFBSTtBQUN0QixZQUFNLGlCQUFpQixDQUFDLEdBQUcsZUFBZTtBQUMxQyxxQkFBZSxhQUFhLElBQUk7QUFBQSxRQUM5QixHQUFHLGVBQWUsYUFBYTtBQUFBLFFBQy9CLEdBQUc7QUFBQSxRQUNILE1BQU0sTUFBTSxLQUFLLG9CQUFJLElBQUksQ0FBQyxHQUFHLGVBQWUsYUFBYSxFQUFFLE1BQU0sR0FBRyxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQUEsUUFDcEYsYUFBWSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ3JDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLENBQUMsR0FBRyxpQkFBaUIsRUFBRSxHQUFHLFdBQVcsSUFBSSxLQUFLLElBQUksRUFBRSxTQUFTLElBQUksS0FBSyxPQUFPLEdBQUcsYUFBWSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLENBQUM7QUFBQSxFQUMvSDtBQUVBLFFBQU0sYUFBYSxNQUFNO0FBQ3ZCLFVBQU0sWUFBWSxTQUFTLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxPQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUUsT0FBTyxPQUFLLE1BQU0sRUFBRTtBQUNsRixRQUFJLGVBQWU7QUFDakIsaUJBQVcsUUFBUSxJQUFJLE9BQUssRUFBRSxPQUFPLGNBQWMsS0FBSyxFQUFFLEdBQUcsR0FBRyxHQUFHLFVBQVUsTUFBTSxVQUFVLElBQUksQ0FBQyxDQUFDO0FBQ25HLGVBQVMsRUFBRSxNQUFNLFdBQVcsT0FBTyxzQkFBc0IsU0FBUyxnQ0FBZ0MsQ0FBQztBQUFBLElBQ3JHLE9BQU87QUFDTCxZQUFNLFlBQVksRUFBRSxNQUFNLFNBQVMsTUFBTSxVQUFVLFNBQVMsVUFBVSxLQUFLLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDekcsaUJBQVcsYUFBYSxTQUFTLFNBQVMsQ0FBQztBQUMzQyxlQUFTLEVBQUUsTUFBTSxXQUFXLE9BQU8saUJBQWlCLFNBQVMsOENBQThDLENBQUM7QUFBQSxJQUM5RztBQUNBLG1CQUFlLEtBQUs7QUFDcEIscUJBQWlCLElBQUk7QUFDckIsZ0JBQVksRUFBRSxNQUFNLElBQUksVUFBVSxJQUFJLEtBQUssSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBRUEsUUFBTSxXQUFXLENBQUMsV0FBbUI7QUFDbkMscUJBQWlCLE1BQU07QUFDdkIsZ0JBQVksRUFBRSxNQUFNLE9BQU8sTUFBTSxVQUFVLE9BQU8sVUFBVSxLQUFLLE9BQU8sS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQzNHLG1CQUFlLElBQUk7QUFBQSxFQUNyQjtBQUVBLFFBQU0sYUFBYSxNQUFNO0FBQ3ZCLFVBQU0sTUFBTSw2QkFBNkIsUUFBUSxJQUFJLE9BQUssR0FBRyxFQUFFLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxFQUFFLEdBQUcsSUFBSSxFQUFFLEtBQUssS0FBSyxHQUFHLENBQUMsRUFBRSxFQUFFLEtBQUssSUFBSTtBQUMzSCxVQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDakQsVUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7QUFDcEMsVUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0FBQ3BDLE1BQUUsT0FBTztBQUNULE1BQUUsV0FBVyx1QkFBc0Isb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDekUsTUFBRSxNQUFNO0FBQUEsRUFDVjtBQUVBLFFBQU0sYUFBYSxDQUFDLE1BQTJDO0FBQzdELFVBQU0sT0FBTyxFQUFFLE9BQU8sUUFBUSxDQUFDO0FBQy9CLFFBQUksQ0FBQyxLQUFNO0FBRVgsVUFBTSxTQUFTLElBQUksV0FBVztBQUM5QixXQUFPLFNBQVMsQ0FBQyxVQUFVO0FBQ3pCLFlBQU0sT0FBTyxNQUFNLFFBQVE7QUFDM0IsWUFBTSxRQUFRLEtBQUssTUFBTSxJQUFJLEVBQUUsTUFBTSxDQUFDO0FBQ3RDLFVBQUksaUJBQWlCLENBQUMsR0FBRyxPQUFPO0FBQ2hDLFVBQUksZ0JBQWdCO0FBRXBCLFlBQU0sT0FBTyxVQUFRLEtBQUssS0FBSyxDQUFDLEVBQUUsUUFBUSxVQUFRO0FBQ2hELGNBQU0sQ0FBQyxNQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDbEQsWUFBSSxLQUFLO0FBQ1AsZ0JBQU0sWUFBWSxFQUFFLE1BQU0sVUFBVSxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sR0FBRyxJQUFJLENBQUMsRUFBRTtBQUMzRSwyQkFBaUIsYUFBYSxnQkFBZ0IsU0FBUztBQUN2RDtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFDRCxpQkFBVyxjQUFjO0FBQ3pCLGVBQVMsRUFBRSxNQUFNLFdBQVcsT0FBTyx3QkFBd0IsU0FBUyxHQUFHLGFBQWEscUNBQXFDLENBQUM7QUFBQSxJQUM1SDtBQUNBLFdBQU8sV0FBVyxJQUFJO0FBQUEsRUFDeEI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNDQUFxQyx3QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLE1BQzNELHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsV0FBTSxNQUFLLFFBQU8sS0FBSyxjQUFjLFVBQVUsWUFBWSxRQUFPLFFBQU8sV0FBVSxZQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUEsUUFDN0YsdUJBQUMsWUFBTyxTQUFTLE1BQU0sbUJBQW1CLElBQUksR0FBRyxXQUFVLDhIQUE2SDtBQUFBLGlDQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBLFVBQUU7QUFBQSxhQUFoTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNOO0FBQUEsUUFDdE4sdUJBQUMsWUFBTyxTQUFTLE1BQU0sWUFBWSxhQUFhLFNBQVMsVUFBVSxNQUFNLEdBQUcsV0FBVSw4SEFBOEg7QUFBQSx1QkFBYSxTQUFTLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsSUFBSyx1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUFHO0FBQUEsVUFBRSxhQUFhLFNBQVMsVUFBVTtBQUFBLGFBQXpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaVU7QUFBQSxRQUNqVSx1QkFBQyxZQUFPLFNBQVMsTUFBTSxhQUFhLFNBQVMsTUFBTSxHQUFHLFdBQVUsOEhBQTZIO0FBQUEsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQSxVQUFFO0FBQUEsYUFBak47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwTjtBQUFBLFFBQzFOLHVCQUFDLFlBQU8sU0FBUyxZQUFZLFdBQVUsOEhBQTZIO0FBQUEsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFBRTtBQUFBLGFBQTFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaU07QUFBQSxRQUNqTSx1QkFBQyxZQUFPLFNBQVMsTUFBTSxlQUFlLElBQUksR0FBRyxXQUFVLHVDQUFzQztBQUFBLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBRTtBQUFBLGFBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUg7QUFBQSxXQU4zSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUMsYUFBYSxTQUNaLHVCQUFDLFNBQUksV0FBVSx5Q0FDWixrQkFBUSxJQUFJLE9BQ1gsdUJBQUMsU0FBZSxXQUFVLDRCQUN4QjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxxQ0FBcUMsWUFBRSxRQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsTUFDekQsdUJBQUMsU0FBSSxXQUFVLHdCQUNYLGFBQUUsUUFBUSxDQUFDLEdBQUcsSUFBSSxPQUFLLHVCQUFDLFVBQWEsV0FBVSxpR0FBaUcsZUFBOUcsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJILENBQU8sS0FEN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTSxTQUFTLENBQUMsR0FBRyxXQUFVLHFEQUFvRCxpQ0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCLEtBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUg7QUFBQSxRQUNySCx1QkFBQyxZQUFPLFNBQVMsTUFBTSxXQUFXLFFBQVEsT0FBTyxRQUFNLEdBQUcsT0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLFdBQVUsa0RBQWlELGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3SjtBQUFBLFdBRjFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUlEsRUFBRSxJQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxDQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLFdBQU0sV0FBVSwyQ0FDZjtBQUFBLDZCQUFDLFdBQU0saUNBQUMsUUFBRyxXQUFVLHVHQUFzRztBQUFBLCtCQUFDLFFBQUcsb0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFRO0FBQUEsUUFBSyx1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQUssdUJBQUMsUUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxRQUFLLHVCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsV0FBeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2SyxLQUFwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlMO0FBQUEsTUFDekwsdUJBQUMsV0FBTyxrQkFBUSxJQUFJLE9BQUssdUJBQUMsUUFBYyxXQUFVLDREQUEyRDtBQUFBLCtCQUFDLFFBQUksWUFBRSxRQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWTtBQUFBLFFBQUssdUJBQUMsUUFBSSxZQUFFLFlBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQUssdUJBQUMsUUFBSyxhQUFFLFFBQVEsQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFBSyx1QkFBQyxRQUFHLGlDQUFDLFlBQU8sU0FBUyxNQUFNLFdBQVcsUUFBUSxPQUFPLFFBQU0sR0FBRyxPQUFPLEVBQUUsRUFBRSxDQUFDLEdBQUcsV0FBVSxhQUFZLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSCxLQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdJO0FBQUEsV0FBclIsRUFBRSxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbVMsQ0FBSyxLQUFqVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1VO0FBQUEsU0FGclU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFHRix1QkFBQyxTQUFNLFFBQVEsYUFBYSxTQUFTLE1BQU07QUFBRSxxQkFBZSxLQUFLO0FBQUcsdUJBQWlCLElBQUk7QUFBRyxrQkFBWSxFQUFFLE1BQU0sSUFBSSxVQUFVLElBQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQUEsSUFBRyxHQUFHLE9BQU8sZ0JBQWdCLG1CQUFtQixxQkFDbk0saUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLFFBQU8sT0FBTyxTQUFTLE1BQU0sVUFBVSxPQUFLLFlBQVksRUFBQyxHQUFHLFVBQVUsTUFBTSxFQUFFLE9BQU8sTUFBSyxDQUFDLEdBQUcsV0FBVSxZQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdKO0FBQUEsTUFDaEosdUJBQUMsV0FBTSxNQUFLLFFBQU8sYUFBWSxZQUFXLE9BQU8sU0FBUyxVQUFVLFVBQVUsT0FBSyxZQUFZLEVBQUMsR0FBRyxVQUFVLFVBQVUsRUFBRSxPQUFPLE1BQUssQ0FBQyxHQUFHLFdBQVUsWUFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0SjtBQUFBLE1BQzVKLHVCQUFDLFdBQU0sTUFBSyxRQUFPLGFBQVksT0FBTSxPQUFPLFNBQVMsS0FBSyxVQUFVLE9BQUssWUFBWSxFQUFDLEdBQUcsVUFBVSxLQUFLLEVBQUUsT0FBTyxNQUFLLENBQUMsR0FBRyxXQUFVLFlBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkk7QUFBQSxNQUM3SSx1QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLGdDQUErQixPQUFPLFNBQVMsTUFBTSxVQUFVLE9BQUssWUFBWSxFQUFDLEdBQUcsVUFBVSxNQUFNLEVBQUUsT0FBTyxNQUFLLENBQUMsR0FBRyxXQUFVLFlBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0s7QUFBQSxNQUN4Syx1QkFBQyxZQUFPLFNBQVMsWUFBWSxXQUFVLHNCQUFxQixzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRTtBQUFBLFNBTHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsU0FBTSxRQUFRLGlCQUFpQixTQUFTLE1BQU0sbUJBQW1CLEtBQUssR0FBRyxPQUFNLDJCQUEwQixVQUFTLG1DQUNqSCxpQ0FBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2QkFBQyxhQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDhCQUE2QixvQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLE9BQUUsc0lBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLFdBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsYUFDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw4QkFBNkIsd0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUNuRSx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFrQyx1QkFBQyxZQUFPLHNDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFBUztBQUFBLGFBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0o7QUFBQSxXQUZ0SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLGFBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsOEJBQTZCLHNDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDakUsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBK0QsdUJBQUMsWUFBTyxtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFBUztBQUFBLGFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMFA7QUFBQSxXQUY1UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErREE7QUFFSjsiLCJuYW1lcyI6W119