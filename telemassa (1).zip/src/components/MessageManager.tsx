import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport1_react["useState"];
import { useLocalStorage } from "/src/hooks/useStorage.ts";
import { Trash2, GripVertical, Type, Image as ImageIcon, Video, CheckSquare, Square } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import { Reorder } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
import Popup from "/src/components/ui/Popup.tsx";
import { sendTelegramMessage } from "/src/services/telegramService.ts";
import { useToast } from "/src/components/ui/Toast.tsx";
export default function MessageManager() {
  const [messages, setMessages] = useLocalStorage("messages", []);
  const [templates, setTemplates] = useLocalStorage("telemassa_templates", []);
  const [history, setHistory] = useLocalStorage("telemassa_history", []);
  const [clients] = useLocalStorage("clients", []);
  const [bots] = useLocalStorage("bots", []);
  const [blocks, setBlocks] = useState([]);
  const [selectedClients, setSelectedClients] = useState([]);
  const [selectedBotId, setSelectedBotId] = useState("");
  const [scheduleType, setScheduleType] = useState("single");
  const [interval, setInterval] = useState(0);
  const [repeatCount, setRepeatCount] = useState(1);
  const [activeTab, setActiveTab] = useState("builder");
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const { addToast } = useToast();
  const addBlock = (type) => {
    setBlocks([...blocks, { id: Date.now().toString(), type, content: "" }]);
  };
  const [searchTerm, setSearchTerm] = useState("");
  const [historyBotFilter, setHistoryBotFilter] = useState("");
  const [delay, setDelay] = useState(0);
  const filteredClients = clients.filter(
    (c) => c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.username.toLowerCase().includes(searchTerm.toLowerCase()) || c.uid.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const toggleAll = () => {
    if (selectedClients.length === filteredClients.length) {
      setSelectedClients(selectedClients.filter((id) => !filteredClients.find((c) => c.id === id)));
    } else {
      const newSelected = [.../* @__PURE__ */ new Set([...selectedClients, ...filteredClients.map((c) => c.id)])];
      setSelectedClients(newSelected);
    }
  };
  const handleFileChange = (e, blockId) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBlocks(blocks.map((b) => b.id === blockId ? { ...b, content: reader.result } : b));
      };
      reader.readAsDataURL(file);
    }
  };
  const sendMessage = async () => {
    const bot = bots.find((b) => b.id === selectedBotId);
    if (!bot || selectedClients.length === 0) {
      addToast({ type: "error", title: "Erro", message: "Selecione um bot e clientes." });
      return;
    }
    const msg = {
      id: Date.now().toString(),
      content: JSON.stringify(blocks),
      type: "text",
      scheduleType,
      interval,
      repeatCount,
      status: "sending",
      botId: bot.id,
      delay
    };
    try {
      for (const clientId of selectedClients) {
        const client = clients.find((c) => c.id === clientId);
        if (client) {
          if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay * 1e3));
          await sendTelegramMessage(bot, client, msg);
        }
      }
      setHistory([...history, { ...msg, date: (/* @__PURE__ */ new Date()).toISOString(), clientIds: selectedClients, status: "Sucesso" }]);
      addToast({ type: "success", title: "Sucesso", message: "Mensagens enviadas!" });
    } catch (e) {
      addToast({ type: "error", title: "Erro", message: "Falha no envio." });
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-12", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 border-b border-gold/10 pb-6", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("builder"), className: `font-cinzel text-xl tracking-widest uppercase ${activeTab === "builder" ? "text-gold" : "text-platina/40"}`, children: "Construtor" }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("history"), className: `font-cinzel text-xl tracking-widest uppercase ${activeTab === "history" ? "text-gold" : "text-platina/40"}`, children: "Histórico" }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 98,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    activeTab === "builder" ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-12", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 glass-card p-8", children: [
      /* @__PURE__ */ jsxDEV("select", { value: selectedBotId, onChange: (e) => setSelectedBotId(e.target.value), className: "w-full", children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Selecione um Bot" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 105,
          columnNumber: 15
        }, this),
        bots.map((bot) => /* @__PURE__ */ jsxDEV("option", { value: bot.id, children: [
          bot.name,
          " (@",
          bot.username,
          ")"
        ] }, bot.id, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 106,
          columnNumber: 32
        }, this))
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 104,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Reorder.Group, { axis: "y", values: blocks, onReorder: setBlocks, className: "space-y-6", children: blocks.map((block) => /* @__PURE__ */ jsxDEV(Reorder.Item, { value: block, className: "bg-bg-1 p-6 rounded-[20px] border border-gold/10 flex items-start gap-4 shadow-lg", children: [
        /* @__PURE__ */ jsxDEV(GripVertical, { className: "text-platina/30 cursor-grab mt-2" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 111,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          block.type === "text" && /* @__PURE__ */ jsxDEV("textarea", { placeholder: "Texto...", onChange: (e) => setBlocks(blocks.map((b) => b.id === block.id ? { ...b, content: e.target.value } : b)), className: "w-full bg-transparent text-champagne font-sans text-sm focus:outline-none" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 113,
            columnNumber: 47
          }, this),
          (block.type === "image" || block.type === "video") && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "URL da Mídia...", value: block.content, onChange: (e) => setBlocks(blocks.map((b) => b.id === block.id ? { ...b, content: e.target.value } : b)), className: "w-full bg-transparent text-champagne font-sans text-sm focus:outline-none" }, void 0, false, {
              fileName: "/app/applet/src/components/MessageManager.tsx",
              lineNumber: 116,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "file", accept: block.type === "image" ? "image/*" : "video/*", onChange: (e) => handleFileChange(e, block.id), className: "w-full text-platina/40 font-mono text-xs" }, void 0, false, {
              fileName: "/app/applet/src/components/MessageManager.tsx",
              lineNumber: 117,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 115,
            columnNumber: 23
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 112,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setBlocks(blocks.filter((b) => b.id !== block.id)), className: "text-platina/30 hover:text-ruby transition-colors", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 121,
          columnNumber: 154
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 121,
          columnNumber: 19
        }, this)
      ] }, block.id, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 110,
        columnNumber: 17
      }, this)) }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 108,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => addBlock("text"), className: "btn-ghost flex items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsxDEV(Type, { size: 14 }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 126,
            columnNumber: 110
          }, this),
          " Texto"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 126,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => addBlock("image"), className: "btn-ghost flex items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsxDEV(ImageIcon, { size: 14 }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 127,
            columnNumber: 111
          }, this),
          " Imagem"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 127,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => addBlock("video"), className: "btn-ghost flex items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsxDEV(Video, { size: 14 }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 128,
            columnNumber: 111
          }, this),
          " Vídeo"
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 128,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 125,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "font-cinzel text-[11px] text-platina/60 tracking-widest uppercase", children: "Delay entre mensagens (segundos):" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 131,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "number", value: delay, onChange: (e) => setDelay(Number(e.target.value)), className: "w-full" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 132,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 130,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setScheduleType("single"), className: `flex-1 p-4 rounded-full border transition-all ${scheduleType === "single" ? "border-gold bg-gold/10 text-gold" : "border-gold/20 text-platina/60 hover:border-gold/50"}`, children: "Envio Único" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 135,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setScheduleType("recurring"), className: `flex-1 p-4 rounded-full border transition-all ${scheduleType === "recurring" ? "border-gold bg-gold/10 text-gold" : "border-gold/20 text-platina/60 hover:border-gold/50"}`, children: "Repetitiva" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 136,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 134,
        columnNumber: 13
      }, this),
      scheduleType === "recurring" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-cinzel text-[11px] text-platina/60 tracking-widest uppercase", children: "Intervalo (segundos):" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 141,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "number", value: interval, onChange: (e) => setInterval(Number(e.target.value)), className: "w-full" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 142,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 140,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-cinzel text-[11px] text-platina/60 tracking-widest uppercase", children: "Repetições:" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 145,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "number", value: repeatCount, onChange: (e) => setRepeatCount(Number(e.target.value)), className: "w-full" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 146,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 144,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 139,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsPopupOpen(true), className: "btn-ghost w-full", children: [
        "Selecionar Clientes (",
        selectedClients.length,
        ")"
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 150,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: sendMessage, className: "btn-primary w-full", children: "Enviar Mensagens" }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 151,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 103,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 102,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "glass-card p-8 space-y-6", children: [
      /* @__PURE__ */ jsxDEV("select", { value: historyBotFilter, onChange: (e) => setHistoryBotFilter(e.target.value), className: "w-full", children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "Todos os Bots" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 157,
          columnNumber: 13
        }, this),
        bots.map((bot) => /* @__PURE__ */ jsxDEV("option", { value: bot.id, children: [
          bot.name,
          " (@",
          bot.username,
          ")"
        ] }, bot.id, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 158,
          columnNumber: 30
        }, this))
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 156,
        columnNumber: 11
      }, this),
      history.filter((h) => historyBotFilter === "" || h.botId === historyBotFilter).map((h, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-6 bg-bg-1 rounded-[20px] border border-gold/10 text-champagne font-sans text-sm hover:border-gold/30 transition-all", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold", children: new Date(h.date).toLocaleString() }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 163,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-platina/50 text-xs font-mono", children: h.status }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 164,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 162,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => {
            setBlocks(JSON.parse(h.content));
            setScheduleType(h.scheduleType);
            setInterval(h.interval || 0);
            setRepeatCount(h.repeatCount || 1);
            setDelay(h.delay || 0);
            setSelectedBotId(h.botId || "");
            setSelectedClients(h.clientIds || []);
            setActiveTab("builder");
          }, className: "btn-primary text-xs px-6 py-2", children: "Reutilizar" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 167,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setHistory(history.filter((_, index) => index !== i)), className: "btn-ghost text-xs px-6 py-2 border-ruby/30 text-ruby hover:bg-ruby/10", children: "Excluir" }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 177,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 166,
          columnNumber: 15
        }, this)
      ] }, i, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 161,
        columnNumber: 13
      }, this))
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 155,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Popup, { isOpen: isPopupOpen, onClose: () => setIsPopupOpen(false), title: "Selecionar Clientes", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Buscar por nome, UID ou username...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 185,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: toggleAll, className: "btn-primary flex-1 text-xs", children: "Selecionar/Deselecionar Filtrados" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 187,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setSelectedClients([]), className: "btn-ghost flex-1 text-xs border-ruby/30 text-ruby hover:bg-ruby/10", children: "Limpar Seleção" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 188,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 186,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-h-96 overflow-y-auto space-y-2", children: filteredClients.map((client) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-4 bg-bg-1 rounded-[12px] border border-gold/10 text-champagne cursor-pointer hover:border-gold/30", onClick: () => setSelectedClients(selectedClients.includes(client.id) ? selectedClients.filter((id) => id !== client.id) : [...selectedClients, client.id]), children: [
        selectedClients.includes(client.id) ? /* @__PURE__ */ jsxDEV(CheckSquare, { className: "stroke-gold" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 193,
          columnNumber: 56
        }, this) : /* @__PURE__ */ jsxDEV(Square, { className: "stroke-platina/30" }, void 0, false, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 193,
          columnNumber: 98
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-sans", children: [
          client.name,
          " (@",
          client.username,
          ") - ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-platina/50", children: client.uid }, void 0, false, {
            fileName: "/app/applet/src/components/MessageManager.tsx",
            lineNumber: 194,
            columnNumber: 82
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/MessageManager.tsx",
          lineNumber: 194,
          columnNumber: 17
        }, this)
      ] }, client.id, true, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 192,
        columnNumber: 15
      }, this)) }, void 0, false, {
        fileName: "/app/applet/src/components/MessageManager.tsx",
        lineNumber: 190,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 184,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/MessageManager.tsx",
      lineNumber: 183,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/MessageManager.tsx",
    lineNumber: 95,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk1lc3NhZ2VNYW5hZ2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VMb2NhbFN0b3JhZ2UgfSBmcm9tICcuLi9ob29rcy91c2VTdG9yYWdlJztcbmltcG9ydCB7IE1lc3NhZ2UsIENsaWVudCwgQm90IGFzIEJvdFR5cGUgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBUcmFzaDIsIEdyaXBWZXJ0aWNhbCwgVHlwZSwgSW1hZ2UgYXMgSW1hZ2VJY29uLCBWaWRlbywgU2VuZCwgQ2hlY2tTcXVhcmUsIFNxdWFyZSwgQ2xvY2ssIFNhdmUsIEhpc3RvcnksIENhbGVuZGFyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IG1vdGlvbiwgUmVvcmRlciB9IGZyb20gJ21vdGlvbi9yZWFjdCc7XG5pbXBvcnQgUG9wdXAgZnJvbSAnLi91aS9Qb3B1cCc7XG5pbXBvcnQgeyBzZW5kVGVsZWdyYW1NZXNzYWdlIH0gZnJvbSAnLi4vc2VydmljZXMvdGVsZWdyYW1TZXJ2aWNlJztcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSAnLi91aS9Ub2FzdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1lc3NhZ2VNYW5hZ2VyKCkge1xuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZUxvY2FsU3RvcmFnZTxNZXNzYWdlW10+KCdtZXNzYWdlcycsIFtdKTtcbiAgY29uc3QgW3RlbXBsYXRlcywgc2V0VGVtcGxhdGVzXSA9IHVzZUxvY2FsU3RvcmFnZTxhbnlbXT4oJ3RlbGVtYXNzYV90ZW1wbGF0ZXMnLCBbXSk7XG4gIGNvbnN0IFtoaXN0b3J5LCBzZXRIaXN0b3J5XSA9IHVzZUxvY2FsU3RvcmFnZTxhbnlbXT4oJ3RlbGVtYXNzYV9oaXN0b3J5JywgW10pO1xuICBjb25zdCBbY2xpZW50c10gPSB1c2VMb2NhbFN0b3JhZ2U8Q2xpZW50W10+KCdjbGllbnRzJywgW10pO1xuICBjb25zdCBbYm90c10gPSB1c2VMb2NhbFN0b3JhZ2U8Qm90VHlwZVtdPignYm90cycsIFtdKTtcbiAgY29uc3QgW2Jsb2Nrcywgc2V0QmxvY2tzXSA9IHVzZVN0YXRlPHtpZDogc3RyaW5nLCB0eXBlOiAndGV4dCcgfCAnaW1hZ2UnIHwgJ3ZpZGVvJywgY29udGVudDogc3RyaW5nfVtdPihbXSk7XG4gIGNvbnN0IFtzZWxlY3RlZENsaWVudHMsIHNldFNlbGVjdGVkQ2xpZW50c10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xuICBjb25zdCBbc2VsZWN0ZWRCb3RJZCwgc2V0U2VsZWN0ZWRCb3RJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW3NjaGVkdWxlVHlwZSwgc2V0U2NoZWR1bGVUeXBlXSA9IHVzZVN0YXRlPCdzaW5nbGUnIHwgJ3JlY3VycmluZyc+KCdzaW5nbGUnKTtcbiAgY29uc3QgW2ludGVydmFsLCBzZXRJbnRlcnZhbF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3JlcGVhdENvdW50LCBzZXRSZXBlYXRDb3VudF0gPSB1c2VTdGF0ZSgxKTtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPCdidWlsZGVyJyB8ICdoaXN0b3J5Jz4oJ2J1aWxkZXInKTtcbiAgY29uc3QgW2lzUG9wdXBPcGVuLCBzZXRJc1BvcHVwT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHsgYWRkVG9hc3QgfSA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgYWRkQmxvY2sgPSAodHlwZTogJ3RleHQnIHwgJ2ltYWdlJyB8ICd2aWRlbycpID0+IHtcbiAgICBzZXRCbG9ja3MoWy4uLmJsb2NrcywgeyBpZDogRGF0ZS5ub3coKS50b1N0cmluZygpLCB0eXBlLCBjb250ZW50OiAnJyB9XSk7XG4gIH07XG5cbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaGlzdG9yeUJvdEZpbHRlciwgc2V0SGlzdG9yeUJvdEZpbHRlcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2RlbGF5LCBzZXREZWxheV0gPSB1c2VTdGF0ZSgwKTtcblxuICBjb25zdCBmaWx0ZXJlZENsaWVudHMgPSBjbGllbnRzLmZpbHRlcihjID0+IFxuICAgIGMubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHwgXG4gICAgYy51c2VybmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHwgXG4gICAgYy51aWQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpXG4gICk7XG5cbiAgY29uc3QgdG9nZ2xlQWxsID0gKCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZENsaWVudHMubGVuZ3RoID09PSBmaWx0ZXJlZENsaWVudHMubGVuZ3RoKSB7XG4gICAgICBzZXRTZWxlY3RlZENsaWVudHMoc2VsZWN0ZWRDbGllbnRzLmZpbHRlcihpZCA9PiAhZmlsdGVyZWRDbGllbnRzLmZpbmQoYyA9PiBjLmlkID09PSBpZCkpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgbmV3U2VsZWN0ZWQgPSBbLi4ubmV3IFNldChbLi4uc2VsZWN0ZWRDbGllbnRzLCAuLi5maWx0ZXJlZENsaWVudHMubWFwKGMgPT4gYy5pZCldKV07XG4gICAgICBzZXRTZWxlY3RlZENsaWVudHMobmV3U2VsZWN0ZWQpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+LCBibG9ja0lkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoZmlsZSkge1xuICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgIHJlYWRlci5vbmxvYWRlbmQgPSAoKSA9PiB7XG4gICAgICAgIHNldEJsb2NrcyhibG9ja3MubWFwKGIgPT4gYi5pZCA9PT0gYmxvY2tJZCA/IHsuLi5iLCBjb250ZW50OiByZWFkZXIucmVzdWx0IGFzIHN0cmluZ30gOiBiKSk7XG4gICAgICB9O1xuICAgICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHNlbmRNZXNzYWdlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGJvdCA9IGJvdHMuZmluZChiID0+IGIuaWQgPT09IHNlbGVjdGVkQm90SWQpO1xuICAgIGlmICghYm90IHx8IHNlbGVjdGVkQ2xpZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGFkZFRvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdFcnJvJywgbWVzc2FnZTogJ1NlbGVjaW9uZSB1bSBib3QgZSBjbGllbnRlcy4nIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG1zZzogTWVzc2FnZSA9IHsgXG4gICAgICBpZDogRGF0ZS5ub3coKS50b1N0cmluZygpLCBcbiAgICAgIGNvbnRlbnQ6IEpTT04uc3RyaW5naWZ5KGJsb2NrcyksIFxuICAgICAgdHlwZTogJ3RleHQnLCBcbiAgICAgIHNjaGVkdWxlVHlwZSwgXG4gICAgICBpbnRlcnZhbCxcbiAgICAgIHJlcGVhdENvdW50LFxuICAgICAgc3RhdHVzOiAnc2VuZGluZycsIFxuICAgICAgYm90SWQ6IGJvdC5pZCwgXG4gICAgICBkZWxheTogZGVsYXkgXG4gICAgfTtcbiAgICBcbiAgICB0cnkge1xuICAgICAgZm9yIChjb25zdCBjbGllbnRJZCBvZiBzZWxlY3RlZENsaWVudHMpIHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY2xpZW50cy5maW5kKGMgPT4gYy5pZCA9PT0gY2xpZW50SWQpO1xuICAgICAgICBpZiAoY2xpZW50KSB7XG4gICAgICAgICAgaWYgKGRlbGF5ID4gMCkgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIGRlbGF5ICogMTAwMCkpO1xuICAgICAgICAgIGF3YWl0IHNlbmRUZWxlZ3JhbU1lc3NhZ2UoYm90LCBjbGllbnQsIG1zZyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHNldEhpc3RvcnkoWy4uLmhpc3RvcnksIHsgLi4ubXNnLCBkYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksIGNsaWVudElkczogc2VsZWN0ZWRDbGllbnRzLCBzdGF0dXM6ICdTdWNlc3NvJyB9XSk7XG4gICAgICBhZGRUb2FzdCh7IHR5cGU6ICdzdWNjZXNzJywgdGl0bGU6ICdTdWNlc3NvJywgbWVzc2FnZTogJ01lbnNhZ2VucyBlbnZpYWRhcyEnIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGFkZFRvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdFcnJvJywgbWVzc2FnZTogJ0ZhbGhhIG5vIGVudmlvLicgfSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTggYm9yZGVyLWIgYm9yZGVyLWdvbGQvMTAgcGItNlwiPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignYnVpbGRlcicpfSBjbGFzc05hbWU9e2Bmb250LWNpbnplbCB0ZXh0LXhsIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgJHthY3RpdmVUYWIgPT09ICdidWlsZGVyJyA/ICd0ZXh0LWdvbGQnIDogJ3RleHQtcGxhdGluYS80MCd9YH0+Q29uc3RydXRvcjwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignaGlzdG9yeScpfSBjbGFzc05hbWU9e2Bmb250LWNpbnplbCB0ZXh0LXhsIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgJHthY3RpdmVUYWIgPT09ICdoaXN0b3J5JyA/ICd0ZXh0LWdvbGQnIDogJ3RleHQtcGxhdGluYS80MCd9YH0+SGlzdMOzcmljbzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHthY3RpdmVUYWIgPT09ICdidWlsZGVyJyA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04IGdsYXNzLWNhcmQgcC04XCI+XG4gICAgICAgICAgICA8c2VsZWN0IHZhbHVlPXtzZWxlY3RlZEJvdElkfSBvbkNoYW5nZT17ZSA9PiBzZXRTZWxlY3RlZEJvdElkKGUudGFyZ2V0LnZhbHVlKX0gY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY2lvbmUgdW0gQm90PC9vcHRpb24+XG4gICAgICAgICAgICAgIHtib3RzLm1hcChib3QgPT4gPG9wdGlvbiBrZXk9e2JvdC5pZH0gdmFsdWU9e2JvdC5pZH0+e2JvdC5uYW1lfSAoQHtib3QudXNlcm5hbWV9KTwvb3B0aW9uPil9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDxSZW9yZGVyLkdyb3VwIGF4aXM9XCJ5XCIgdmFsdWVzPXtibG9ja3N9IG9uUmVvcmRlcj17c2V0QmxvY2tzfSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAge2Jsb2Nrcy5tYXAoYmxvY2sgPT4gKFxuICAgICAgICAgICAgICAgIDxSZW9yZGVyLkl0ZW0ga2V5PXtibG9jay5pZH0gdmFsdWU9e2Jsb2NrfSBjbGFzc05hbWU9XCJiZy1iZy0xIHAtNiByb3VuZGVkLVsyMHB4XSBib3JkZXIgYm9yZGVyLWdvbGQvMTAgZmxleCBpdGVtcy1zdGFydCBnYXAtNCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxHcmlwVmVydGljYWwgY2xhc3NOYW1lPVwidGV4dC1wbGF0aW5hLzMwIGN1cnNvci1ncmFiIG10LTJcIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAge2Jsb2NrLnR5cGUgPT09ICd0ZXh0JyAmJiA8dGV4dGFyZWEgcGxhY2Vob2xkZXI9XCJUZXh0by4uLlwiIG9uQ2hhbmdlPXtlID0+IHNldEJsb2NrcyhibG9ja3MubWFwKGIgPT4gYi5pZCA9PT0gYmxvY2suaWQgPyB7Li4uYiwgY29udGVudDogZS50YXJnZXQudmFsdWV9IDogYikpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC1jaGFtcGFnbmUgZm9udC1zYW5zIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIHsoYmxvY2sudHlwZSA9PT0gJ2ltYWdlJyB8fCBibG9jay50eXBlID09PSAndmlkZW8nKSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiVVJMIGRhIE3DrWRpYS4uLlwiIHZhbHVlPXtibG9jay5jb250ZW50fSBvbkNoYW5nZT17ZSA9PiBzZXRCbG9ja3MoYmxvY2tzLm1hcChiID0+IGIuaWQgPT09IGJsb2NrLmlkID8gey4uLmIsIGNvbnRlbnQ6IGUudGFyZ2V0LnZhbHVlfSA6IGIpKX0gY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtY2hhbXBhZ25lIGZvbnQtc2FucyB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9e2Jsb2NrLnR5cGUgPT09ICdpbWFnZScgPyAnaW1hZ2UvKicgOiAndmlkZW8vKid9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUZpbGVDaGFuZ2UoZSwgYmxvY2suaWQpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1wbGF0aW5hLzQwIGZvbnQtbW9ubyB0ZXh0LXhzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRCbG9ja3MoYmxvY2tzLmZpbHRlcihiID0+IGIuaWQgIT09IGJsb2NrLmlkKSl9IGNsYXNzTmFtZT1cInRleHQtcGxhdGluYS8zMCBob3Zlcjp0ZXh0LXJ1YnkgdHJhbnNpdGlvbi1jb2xvcnNcIj48VHJhc2gyIHNpemU9ezE4fSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvUmVvcmRlci5JdGVtPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvUmVvcmRlci5Hcm91cD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZEJsb2NrKCd0ZXh0Jyl9IGNsYXNzTmFtZT1cImJ0bi1naG9zdCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzXCI+PFR5cGUgc2l6ZT17MTR9Lz4gVGV4dG88L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBhZGRCbG9jaygnaW1hZ2UnKX0gY2xhc3NOYW1lPVwiYnRuLWdob3N0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHNcIj48SW1hZ2VJY29uIHNpemU9ezE0fS8+IEltYWdlbTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZEJsb2NrKCd2aWRlbycpfSBjbGFzc05hbWU9XCJidG4tZ2hvc3QgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14c1wiPjxWaWRlbyBzaXplPXsxNH0vPiBWw61kZW88L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtY2luemVsIHRleHQtWzExcHhdIHRleHQtcGxhdGluYS82MCB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlXCI+RGVsYXkgZW50cmUgbWVuc2FnZW5zIChzZWd1bmRvcyk6PC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17ZGVsYXl9IG9uQ2hhbmdlPXtlID0+IHNldERlbGF5KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTY2hlZHVsZVR5cGUoJ3NpbmdsZScpfSBjbGFzc05hbWU9e2BmbGV4LTEgcC00IHJvdW5kZWQtZnVsbCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtzY2hlZHVsZVR5cGUgPT09ICdzaW5nbGUnID8gJ2JvcmRlci1nb2xkIGJnLWdvbGQvMTAgdGV4dC1nb2xkJyA6ICdib3JkZXItZ29sZC8yMCB0ZXh0LXBsYXRpbmEvNjAgaG92ZXI6Ym9yZGVyLWdvbGQvNTAnfWB9PkVudmlvIMOabmljbzwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNjaGVkdWxlVHlwZSgncmVjdXJyaW5nJyl9IGNsYXNzTmFtZT17YGZsZXgtMSBwLTQgcm91bmRlZC1mdWxsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke3NjaGVkdWxlVHlwZSA9PT0gJ3JlY3VycmluZycgPyAnYm9yZGVyLWdvbGQgYmctZ29sZC8xMCB0ZXh0LWdvbGQnIDogJ2JvcmRlci1nb2xkLzIwIHRleHQtcGxhdGluYS82MCBob3Zlcjpib3JkZXItZ29sZC81MCd9YH0+UmVwZXRpdGl2YTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7c2NoZWR1bGVUeXBlID09PSAncmVjdXJyaW5nJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1bMTFweF0gdGV4dC1wbGF0aW5hLzYwIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2VcIj5JbnRlcnZhbG8gKHNlZ3VuZG9zKTo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17aW50ZXJ2YWx9IG9uQ2hhbmdlPXtlID0+IHNldEludGVydmFsKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1bMTFweF0gdGV4dC1wbGF0aW5hLzYwIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2VcIj5SZXBldGnDp8O1ZXM6PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e3JlcGVhdENvdW50fSBvbkNoYW5nZT17ZSA9PiBzZXRSZXBlYXRDb3VudChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0gY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRJc1BvcHVwT3Blbih0cnVlKX0gY2xhc3NOYW1lPVwiYnRuLWdob3N0IHctZnVsbFwiPlNlbGVjaW9uYXIgQ2xpZW50ZXMgKHtzZWxlY3RlZENsaWVudHMubGVuZ3RofSk8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17c2VuZE1lc3NhZ2V9IGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IHctZnVsbFwiPkVudmlhciBNZW5zYWdlbnM8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgcC04IHNwYWNlLXktNlwiPlxuICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e2hpc3RvcnlCb3RGaWx0ZXJ9IG9uQ2hhbmdlPXtlID0+IHNldEhpc3RvcnlCb3RGaWx0ZXIoZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2RvcyBvcyBCb3RzPC9vcHRpb24+XG4gICAgICAgICAgICB7Ym90cy5tYXAoYm90ID0+IDxvcHRpb24ga2V5PXtib3QuaWR9IHZhbHVlPXtib3QuaWR9Pntib3QubmFtZX0gKEB7Ym90LnVzZXJuYW1lfSk8L29wdGlvbj4pfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIHtoaXN0b3J5LmZpbHRlcihoID0+IGhpc3RvcnlCb3RGaWx0ZXIgPT09ICcnIHx8IGguYm90SWQgPT09IGhpc3RvcnlCb3RGaWx0ZXIpLm1hcCgoaCwgaSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwLTYgYmctYmctMSByb3VuZGVkLVsyMHB4XSBib3JkZXIgYm9yZGVyLWdvbGQvMTAgdGV4dC1jaGFtcGFnbmUgZm9udC1zYW5zIHRleHQtc20gaG92ZXI6Ym9yZGVyLWdvbGQvMzAgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkXCI+e25ldyBEYXRlKGguZGF0ZSkudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wbGF0aW5hLzUwIHRleHQteHMgZm9udC1tb25vXCI+e2guc3RhdHVzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0QmxvY2tzKEpTT04ucGFyc2UoaC5jb250ZW50KSk7XG4gICAgICAgICAgICAgICAgICBzZXRTY2hlZHVsZVR5cGUoaC5zY2hlZHVsZVR5cGUpO1xuICAgICAgICAgICAgICAgICAgc2V0SW50ZXJ2YWwoaC5pbnRlcnZhbCB8fCAwKTtcbiAgICAgICAgICAgICAgICAgIHNldFJlcGVhdENvdW50KGgucmVwZWF0Q291bnQgfHwgMSk7XG4gICAgICAgICAgICAgICAgICBzZXREZWxheShoLmRlbGF5IHx8IDApO1xuICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRCb3RJZChoLmJvdElkIHx8ICcnKTtcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQ2xpZW50cyhoLmNsaWVudElkcyB8fCBbXSk7XG4gICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIoJ2J1aWxkZXInKTtcbiAgICAgICAgICAgICAgICB9fSBjbGFzc05hbWU9XCJidG4tcHJpbWFyeSB0ZXh0LXhzIHB4LTYgcHktMlwiPlJldXRpbGl6YXI8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEhpc3RvcnkoaGlzdG9yeS5maWx0ZXIoKF8sIGluZGV4KSA9PiBpbmRleCAhPT0gaSkpfSBjbGFzc05hbWU9XCJidG4tZ2hvc3QgdGV4dC14cyBweC02IHB5LTIgYm9yZGVyLXJ1YnkvMzAgdGV4dC1ydWJ5IGhvdmVyOmJnLXJ1YnkvMTBcIj5FeGNsdWlyPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIDxQb3B1cCBpc09wZW49e2lzUG9wdXBPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc1BvcHVwT3BlbihmYWxzZSl9IHRpdGxlPVwiU2VsZWNpb25hciBDbGllbnRlc1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHBvciBub21lLCBVSUQgb3UgdXNlcm5hbWUuLi5cIiB2YWx1ZT17c2VhcmNoVGVybX0gb25DaGFuZ2U9e2UgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbFwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZUFsbH0gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleC0xIHRleHQteHNcIj5TZWxlY2lvbmFyL0Rlc2VsZWNpb25hciBGaWx0cmFkb3M8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRDbGllbnRzKFtdKX0gY2xhc3NOYW1lPVwiYnRuLWdob3N0IGZsZXgtMSB0ZXh0LXhzIGJvcmRlci1ydWJ5LzMwIHRleHQtcnVieSBob3ZlcjpiZy1ydWJ5LzEwXCI+TGltcGFyIFNlbGXDp8OjbzwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtOTYgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAge2ZpbHRlcmVkQ2xpZW50cy5tYXAoY2xpZW50ID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2NsaWVudC5pZH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgcC00IGJnLWJnLTEgcm91bmRlZC1bMTJweF0gYm9yZGVyIGJvcmRlci1nb2xkLzEwIHRleHQtY2hhbXBhZ25lIGN1cnNvci1wb2ludGVyIGhvdmVyOmJvcmRlci1nb2xkLzMwXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRDbGllbnRzKHNlbGVjdGVkQ2xpZW50cy5pbmNsdWRlcyhjbGllbnQuaWQpID8gc2VsZWN0ZWRDbGllbnRzLmZpbHRlcihpZCA9PiBpZCAhPT0gY2xpZW50LmlkKSA6IFsuLi5zZWxlY3RlZENsaWVudHMsIGNsaWVudC5pZF0pfT5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDbGllbnRzLmluY2x1ZGVzKGNsaWVudC5pZCkgPyA8Q2hlY2tTcXVhcmUgY2xhc3NOYW1lPVwic3Ryb2tlLWdvbGRcIiAvPiA6IDxTcXVhcmUgY2xhc3NOYW1lPVwic3Ryb2tlLXBsYXRpbmEvMzBcIiAvPn1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNhbnNcIj57Y2xpZW50Lm5hbWV9IChAe2NsaWVudC51c2VybmFtZX0pIC0gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtcGxhdGluYS81MFwiPntjbGllbnQudWlkfTwvc3Bhbj48L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Qb3B1cD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBZ0dRO0FBaEdSLFNBQWdCLGdCQUFnQjtBQUNoQyxTQUFTLHVCQUF1QjtBQUVoQyxTQUFTLFFBQVEsY0FBYyxNQUFNLFNBQVMsV0FBVyxPQUFhLGFBQWEsY0FBOEM7QUFDakksU0FBaUIsZUFBZTtBQUNoQyxPQUFPLFdBQVc7QUFDbEIsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxnQkFBZ0I7QUFFekIsd0JBQXdCLGlCQUFpQjtBQUN2QyxRQUFNLENBQUMsVUFBVSxXQUFXLElBQUksZ0JBQTJCLFlBQVksQ0FBQyxDQUFDO0FBQ3pFLFFBQU0sQ0FBQyxXQUFXLFlBQVksSUFBSSxnQkFBdUIsdUJBQXVCLENBQUMsQ0FBQztBQUNsRixRQUFNLENBQUMsU0FBUyxVQUFVLElBQUksZ0JBQXVCLHFCQUFxQixDQUFDLENBQUM7QUFDNUUsUUFBTSxDQUFDLE9BQU8sSUFBSSxnQkFBMEIsV0FBVyxDQUFDLENBQUM7QUFDekQsUUFBTSxDQUFDLElBQUksSUFBSSxnQkFBMkIsUUFBUSxDQUFDLENBQUM7QUFDcEQsUUFBTSxDQUFDLFFBQVEsU0FBUyxJQUFJLFNBQTRFLENBQUMsQ0FBQztBQUMxRyxRQUFNLENBQUMsaUJBQWlCLGtCQUFrQixJQUFJLFNBQW1CLENBQUMsQ0FBQztBQUNuRSxRQUFNLENBQUMsZUFBZSxnQkFBZ0IsSUFBSSxTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQyxjQUFjLGVBQWUsSUFBSSxTQUFpQyxRQUFRO0FBQ2pGLFFBQU0sQ0FBQyxVQUFVLFdBQVcsSUFBSSxTQUFTLENBQUM7QUFDMUMsUUFBTSxDQUFDLGFBQWEsY0FBYyxJQUFJLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUMsV0FBVyxZQUFZLElBQUksU0FBZ0MsU0FBUztBQUMzRSxRQUFNLENBQUMsYUFBYSxjQUFjLElBQUksU0FBUyxLQUFLO0FBQ3BELFFBQU0sRUFBRSxTQUFTLElBQUksU0FBUztBQUU5QixRQUFNLFdBQVcsQ0FBQyxTQUFxQztBQUNyRCxjQUFVLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxLQUFLLElBQUksRUFBRSxTQUFTLEdBQUcsTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDO0FBQUEsRUFDekU7QUFFQSxRQUFNLENBQUMsWUFBWSxhQUFhLElBQUksU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQyxrQkFBa0IsbUJBQW1CLElBQUksU0FBaUIsRUFBRTtBQUNuRSxRQUFNLENBQUMsT0FBTyxRQUFRLElBQUksU0FBUyxDQUFDO0FBRXBDLFFBQU0sa0JBQWtCLFFBQVE7QUFBQSxJQUFPLE9BQ3JDLEVBQUUsS0FBSyxZQUFZLEVBQUUsU0FBUyxXQUFXLFlBQVksQ0FBQyxLQUN0RCxFQUFFLFNBQVMsWUFBWSxFQUFFLFNBQVMsV0FBVyxZQUFZLENBQUMsS0FDMUQsRUFBRSxJQUFJLFlBQVksRUFBRSxTQUFTLFdBQVcsWUFBWSxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNLFlBQVksTUFBTTtBQUN0QixRQUFJLGdCQUFnQixXQUFXLGdCQUFnQixRQUFRO0FBQ3JELHlCQUFtQixnQkFBZ0IsT0FBTyxRQUFNLENBQUMsZ0JBQWdCLEtBQUssT0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7QUFBQSxJQUMxRixPQUFPO0FBQ0wsWUFBTSxjQUFjLENBQUMsR0FBRyxvQkFBSSxJQUFJLENBQUMsR0FBRyxpQkFBaUIsR0FBRyxnQkFBZ0IsSUFBSSxPQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4Rix5QkFBbUIsV0FBVztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUVBLFFBQU0sbUJBQW1CLENBQUMsR0FBd0MsWUFBb0I7QUFDcEYsVUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRLENBQUM7QUFDL0IsUUFBSSxNQUFNO0FBQ1IsWUFBTSxTQUFTLElBQUksV0FBVztBQUM5QixhQUFPLFlBQVksTUFBTTtBQUN2QixrQkFBVSxPQUFPLElBQUksT0FBSyxFQUFFLE9BQU8sVUFBVSxFQUFDLEdBQUcsR0FBRyxTQUFTLE9BQU8sT0FBZ0IsSUFBSSxDQUFDLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU8sY0FBYyxJQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTSxjQUFjLFlBQVk7QUFDOUIsVUFBTSxNQUFNLEtBQUssS0FBSyxPQUFLLEVBQUUsT0FBTyxhQUFhO0FBQ2pELFFBQUksQ0FBQyxPQUFPLGdCQUFnQixXQUFXLEdBQUc7QUFDeEMsZUFBUyxFQUFFLE1BQU0sU0FBUyxPQUFPLFFBQVEsU0FBUywrQkFBK0IsQ0FBQztBQUNsRjtBQUFBLElBQ0Y7QUFFQSxVQUFNLE1BQWU7QUFBQSxNQUNuQixJQUFJLEtBQUssSUFBSSxFQUFFLFNBQVM7QUFBQSxNQUN4QixTQUFTLEtBQUssVUFBVSxNQUFNO0FBQUEsTUFDOUIsTUFBTTtBQUFBLE1BQ047QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsUUFBUTtBQUFBLE1BQ1IsT0FBTyxJQUFJO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsaUJBQVcsWUFBWSxpQkFBaUI7QUFDdEMsY0FBTSxTQUFTLFFBQVEsS0FBSyxPQUFLLEVBQUUsT0FBTyxRQUFRO0FBQ2xELFlBQUksUUFBUTtBQUNWLGNBQUksUUFBUSxFQUFHLE9BQU0sSUFBSSxRQUFRLGFBQVcsV0FBVyxTQUFTLFFBQVEsR0FBSSxDQUFDO0FBQzdFLGdCQUFNLG9CQUFvQixLQUFLLFFBQVEsR0FBRztBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUNBLGlCQUFXLENBQUMsR0FBRyxTQUFTLEVBQUUsR0FBRyxLQUFLLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVksR0FBRyxXQUFXLGlCQUFpQixRQUFRLFVBQVUsQ0FBQyxDQUFDO0FBQ2xILGVBQVMsRUFBRSxNQUFNLFdBQVcsT0FBTyxXQUFXLFNBQVMsc0JBQXNCLENBQUM7QUFBQSxJQUNoRixTQUFTLEdBQUc7QUFDVixlQUFTLEVBQUUsTUFBTSxTQUFTLE9BQU8sUUFBUSxTQUFTLGtCQUFrQixDQUFDO0FBQUEsSUFDdkU7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLDZCQUFDLFlBQU8sU0FBUyxNQUFNLGFBQWEsU0FBUyxHQUFHLFdBQVcsaURBQWlELGNBQWMsWUFBWSxjQUFjLGlCQUFpQixJQUFJLDBCQUF6SztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1MO0FBQUEsTUFDbkwsdUJBQUMsWUFBTyxTQUFTLE1BQU0sYUFBYSxTQUFTLEdBQUcsV0FBVyxpREFBaUQsY0FBYyxZQUFZLGNBQWMsaUJBQWlCLElBQUkseUJBQXpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0w7QUFBQSxTQUZwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVDLGNBQWMsWUFDYix1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsNkJBQUMsWUFBTyxPQUFPLGVBQWUsVUFBVSxPQUFLLGlCQUFpQixFQUFFLE9BQU8sS0FBSyxHQUFHLFdBQVUsVUFDdkY7QUFBQSwrQkFBQyxZQUFPLE9BQU0sSUFBRyxnQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2hDLEtBQUssSUFBSSxTQUFPLHVCQUFDLFlBQW9CLE9BQU8sSUFBSSxJQUFLO0FBQUEsY0FBSTtBQUFBLFVBQUs7QUFBQSxVQUFJLElBQUk7QUFBQSxVQUFTO0FBQUEsYUFBbEQsSUFBSSxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFLENBQVM7QUFBQSxXQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFFBQVEsT0FBUixFQUFjLE1BQUssS0FBSSxRQUFRLFFBQVEsV0FBVyxXQUFXLFdBQVUsYUFDckUsaUJBQU8sSUFBSSxXQUNWLHVCQUFDLFFBQVEsTUFBUixFQUE0QixPQUFPLE9BQU8sV0FBVSxxRkFDbkQ7QUFBQSwrQkFBQyxnQkFBYSxXQUFVLHNDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsU0FBSSxXQUFVLFVBQ1o7QUFBQSxnQkFBTSxTQUFTLFVBQVUsdUJBQUMsY0FBUyxhQUFZLFlBQVcsVUFBVSxPQUFLLFVBQVUsT0FBTyxJQUFJLE9BQUssRUFBRSxPQUFPLE1BQU0sS0FBSyxFQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxNQUFLLElBQUksQ0FBQyxDQUFDLEdBQUcsV0FBVSwrRUFBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMk47QUFBQSxXQUNuUCxNQUFNLFNBQVMsV0FBVyxNQUFNLFNBQVMsWUFDekMsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxXQUFNLE1BQUssUUFBTyxhQUFZLG1CQUFrQixPQUFPLE1BQU0sU0FBUyxVQUFVLE9BQUssVUFBVSxPQUFPLElBQUksT0FBSyxFQUFFLE9BQU8sTUFBTSxLQUFLLEVBQUMsR0FBRyxHQUFHLFNBQVMsRUFBRSxPQUFPLE1BQUssSUFBSSxDQUFDLENBQUMsR0FBRyxXQUFVLCtFQUFyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpUTtBQUFBLFlBQ2pRLHVCQUFDLFdBQU0sTUFBSyxRQUFPLFFBQVEsTUFBTSxTQUFTLFVBQVUsWUFBWSxXQUFXLFVBQVUsT0FBSyxpQkFBaUIsR0FBRyxNQUFNLEVBQUUsR0FBRyxXQUFVLDhDQUFuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SztBQUFBLGVBRmhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU0sVUFBVSxPQUFPLE9BQU8sT0FBSyxFQUFFLE9BQU8sTUFBTSxFQUFFLENBQUMsR0FBRyxXQUFVLHFEQUFvRCxpQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCLEtBQXpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMko7QUFBQSxXQVgxSSxNQUFNLElBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQSxDQUNELEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxZQUFPLFNBQVMsTUFBTSxTQUFTLE1BQU0sR0FBRyxXQUFVLDZDQUE0QztBQUFBLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUFFO0FBQUEsYUFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3RILHVCQUFDLFlBQU8sU0FBUyxNQUFNLFNBQVMsT0FBTyxHQUFHLFdBQVUsNkNBQTRDO0FBQUEsaUNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFBRTtBQUFBLGFBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkg7QUFBQSxRQUM3SCx1QkFBQyxZQUFPLFNBQVMsTUFBTSxTQUFTLE9BQU8sR0FBRyxXQUFVLDZDQUE0QztBQUFBLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFBRTtBQUFBLGFBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0g7QUFBQSxXQUgxSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHFFQUFvRSxpREFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSDtBQUFBLFFBQ3RILHVCQUFDLFdBQU0sTUFBSyxVQUFTLE9BQU8sT0FBTyxVQUFVLE9BQUssU0FBUyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxXQUFVLFlBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsWUFBTyxTQUFTLE1BQU0sZ0JBQWdCLFFBQVEsR0FBRyxXQUFXLGlEQUFpRCxpQkFBaUIsV0FBVyxxQ0FBcUMscURBQXFELElBQUksMkJBQXhPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbVA7QUFBQSxRQUNuUCx1QkFBQyxZQUFPLFNBQVMsTUFBTSxnQkFBZ0IsV0FBVyxHQUFHLFdBQVcsaURBQWlELGlCQUFpQixjQUFjLHFDQUFxQyxxREFBcUQsSUFBSSwwQkFBOU87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3UDtBQUFBLFdBRjFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0MsaUJBQWlCLGVBQ2hCLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFFQUFvRSxxQ0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxVQUMxRyx1QkFBQyxXQUFNLE1BQUssVUFBUyxPQUFPLFVBQVUsVUFBVSxPQUFLLFlBQVksT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDLEdBQUcsV0FBVSxZQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLGFBRi9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUscUVBQW9FLDJCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRztBQUFBLFVBQ2hHLHVCQUFDLFdBQU0sTUFBSyxVQUFTLE9BQU8sYUFBYSxVQUFVLE9BQUssZUFBZSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxXQUFVLFlBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1IO0FBQUEsYUFGckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVGLHVCQUFDLFlBQU8sU0FBUyxNQUFNLGVBQWUsSUFBSSxHQUFHLFdBQVUsb0JBQW1CO0FBQUE7QUFBQSxRQUFzQixnQkFBZ0I7QUFBQSxRQUFPO0FBQUEsV0FBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SDtBQUFBLE1BQ3hILHVCQUFDLFlBQU8sU0FBUyxhQUFhLFdBQVUsc0JBQXFCLGdDQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsU0FoRC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREEsS0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1EQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDZCQUFDLFlBQU8sT0FBTyxrQkFBa0IsVUFBVSxPQUFLLG9CQUFvQixFQUFFLE9BQU8sS0FBSyxHQUFHLFdBQVUsVUFDN0Y7QUFBQSwrQkFBQyxZQUFPLE9BQU0sSUFBRyw2QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQzdCLEtBQUssSUFBSSxTQUFPLHVCQUFDLFlBQW9CLE9BQU8sSUFBSSxJQUFLO0FBQUEsY0FBSTtBQUFBLFVBQUs7QUFBQSxVQUFJLElBQUk7QUFBQSxVQUFTO0FBQUEsYUFBbEQsSUFBSSxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFLENBQVM7QUFBQSxXQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNDLFFBQVEsT0FBTyxPQUFLLHFCQUFxQixNQUFNLEVBQUUsVUFBVSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsR0FBRyxNQUNwRix1QkFBQyxTQUFZLFdBQVUsMkpBQ3JCO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSx1QkFBdUIsY0FBSSxLQUFLLEVBQUUsSUFBSSxFQUFFLGVBQWUsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxVQUFLLFdBQVUscUNBQXFDLFlBQUUsVUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxhQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsWUFBTyxTQUFTLE1BQU07QUFDckIsc0JBQVUsS0FBSyxNQUFNLEVBQUUsT0FBTyxDQUFDO0FBQy9CLDRCQUFnQixFQUFFLFlBQVk7QUFDOUIsd0JBQVksRUFBRSxZQUFZLENBQUM7QUFDM0IsMkJBQWUsRUFBRSxlQUFlLENBQUM7QUFDakMscUJBQVMsRUFBRSxTQUFTLENBQUM7QUFDckIsNkJBQWlCLEVBQUUsU0FBUyxFQUFFO0FBQzlCLCtCQUFtQixFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQ3BDLHlCQUFhLFNBQVM7QUFBQSxVQUN4QixHQUFHLFdBQVUsaUNBQWdDLDBCQVQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVN1RDtBQUFBLFVBQ3ZELHVCQUFDLFlBQU8sU0FBUyxNQUFNLFdBQVcsUUFBUSxPQUFPLENBQUMsR0FBRyxVQUFVLFVBQVUsQ0FBQyxDQUFDLEdBQUcsV0FBVSx5RUFBd0UsdUJBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVLO0FBQUEsYUFYeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0FqQlEsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBLENBQ0Q7QUFBQSxTQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFFRix1QkFBQyxTQUFNLFFBQVEsYUFBYSxTQUFTLE1BQU0sZUFBZSxLQUFLLEdBQUcsT0FBTSx1QkFDdEUsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLHVDQUFzQyxPQUFPLFlBQVksVUFBVSxPQUFLLGNBQWMsRUFBRSxPQUFPLEtBQUssR0FBRyxXQUFVLFlBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUo7QUFBQSxNQUN6Six1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUyxXQUFXLFdBQVUsOEJBQTZCLGlEQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsUUFDcEcsdUJBQUMsWUFBTyxTQUFTLE1BQU0sbUJBQW1CLENBQUMsQ0FBQyxHQUFHLFdBQVUsc0VBQXFFLDhCQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRJO0FBQUEsV0FGOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ1osMEJBQWdCLElBQUksWUFDbkIsdUJBQUMsU0FBb0IsV0FBVSwrSEFBOEgsU0FBUyxNQUFNLG1CQUFtQixnQkFBZ0IsU0FBUyxPQUFPLEVBQUUsSUFBSSxnQkFBZ0IsT0FBTyxRQUFNLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLGlCQUFpQixPQUFPLEVBQUUsQ0FBQyxHQUNsVDtBQUFBLHdCQUFnQixTQUFTLE9BQU8sRUFBRSxJQUFJLHVCQUFDLGVBQVksV0FBVSxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQyxJQUFLLHVCQUFDLFVBQU8sV0FBVSx1QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFFBQ3ZILHVCQUFDLFVBQUssV0FBVSxhQUFhO0FBQUEsaUJBQU87QUFBQSxVQUFLO0FBQUEsVUFBSSxPQUFPO0FBQUEsVUFBUztBQUFBLFVBQUksdUJBQUMsVUFBSyxXQUFVLDZCQUE2QixpQkFBTyxPQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0k7QUFBQSxXQUZ4SCxPQUFPLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxDQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsT0F4R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQTtBQUVKOyIsIm5hbWVzIjpbXX0=