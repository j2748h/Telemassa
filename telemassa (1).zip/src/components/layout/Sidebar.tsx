import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=54c12b95";
import { LayoutDashboard, Bot, MessageSquare, Users } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
export default function Sidebar() {
  const location = useLocation();
  const navItems = [
    { path: "/", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/bots", icon: Bot, label: "Bots" },
    { path: "/messages", icon: MessageSquare, label: "Mensagens" },
    { path: "/clients", icon: Users, label: "Clientes" }
  ];
  return /* @__PURE__ */ jsxDEV("aside", { className: "w-[260px] bg-[#080808] border-r border-gold/10 flex flex-col h-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-8 flex flex-col gap-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("svg", { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "#D4AF37", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ jsxDEV("path", { d: "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" }, void 0, false, {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 18,
          columnNumber: 153
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 18,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "font-serif text-2xl font-black bg-[linear-gradient(to_right,#D4AF37,#F5D76E)] bg-clip-text text-transparent", children: "TeleMassa" }, void 0, false, {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 19,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/layout/Sidebar.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "font-cinzel text-[10px] text-platina tracking-widest uppercase", children: "Premium Messaging" }, void 0, false, {
        fileName: "/app/applet/src/components/layout/Sidebar.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/layout/Sidebar.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "flex-1 px-4 space-y-1", children: navItems.map((item) => {
      const isActive = location.pathname === item.path;
      return /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: item.path,
          className: `flex items-center gap-3 px-4 py-3 rounded-r-xl transition-all duration-200 ${isActive ? "bg-gold/10 text-gold border-l-4 border-gold" : "text-platina/60 hover:text-gold hover:bg-gold/5"}`,
          children: [
            /* @__PURE__ */ jsxDEV(item.icon, { size: 20, className: isActive ? "stroke-gold" : "stroke-platina/60" }, void 0, false, {
              fileName: "/app/applet/src/components/layout/Sidebar.tsx",
              lineNumber: 32,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-cinzel text-sm", children: item.label }, void 0, false, {
              fileName: "/app/applet/src/components/layout/Sidebar.tsx",
              lineNumber: 33,
              columnNumber: 15
            }, this)
          ]
        },
        item.path,
        true,
        {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 27,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "/app/applet/src/components/layout/Sidebar.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-t border-gold/10 space-y-4", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => {
            if (window.confirm("Tem certeza que deseja limpar todos os dados? Isso não pode ser desfeito.")) {
              window.localStorage.clear();
              window.location.reload();
            }
          },
          className: "w-full py-2 text-[10px] font-mono text-ruby/40 hover:text-ruby transition-colors uppercase tracking-widest text-left",
          children: "Limpar Sistema"
        },
        void 0,
        false,
        {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 39,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between font-mono text-[10px] text-platina/30 uppercase tracking-widest", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "v2.0.5" }, void 0, false, {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-gold/40", children: "Premium" }, void 0, false, {
          fileName: "/app/applet/src/components/layout/Sidebar.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/layout/Sidebar.tsx",
        lineNumber: 50,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/layout/Sidebar.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/layout/Sidebar.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNpZGViYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBMYXlvdXREYXNoYm9hcmQsIEJvdCwgTWVzc2FnZVNxdWFyZSwgVXNlcnMsIFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpZGViYXIoKSB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICBjb25zdCBuYXZJdGVtcyA9IFtcbiAgICB7IHBhdGg6ICcvJywgaWNvbjogTGF5b3V0RGFzaGJvYXJkLCBsYWJlbDogJ0Rhc2hib2FyZCcgfSxcbiAgICB7IHBhdGg6ICcvYm90cycsIGljb246IEJvdCwgbGFiZWw6ICdCb3RzJyB9LFxuICAgIHsgcGF0aDogJy9tZXNzYWdlcycsIGljb246IE1lc3NhZ2VTcXVhcmUsIGxhYmVsOiAnTWVuc2FnZW5zJyB9LFxuICAgIHsgcGF0aDogJy9jbGllbnRzJywgaWNvbjogVXNlcnMsIGxhYmVsOiAnQ2xpZW50ZXMnIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwidy1bMjYwcHhdIGJnLVsjMDgwODA4XSBib3JkZXItciBib3JkZXItZ29sZC8xMCBmbGV4IGZsZXgtY29sIGgtc2NyZWVuXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCBmbGV4IGZsZXgtY29sIGdhcC0xXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiI0Q0QUYzN1wiIHN0cm9rZVdpZHRoPVwiMS41XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiPjxwYXRoIGQ9XCJNMjIgMkwxMSAxM00yMiAybC03IDIwLTQtOS05LTQgMjAtN3pcIi8+PC9zdmc+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1zZXJpZiB0ZXh0LTJ4bCBmb250LWJsYWNrIGJnLVtsaW5lYXItZ3JhZGllbnQodG9fcmlnaHQsI0Q0QUYzNywjRjVENzZFKV0gYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5UZWxlTWFzc2E8L2gxPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1jaW56ZWwgdGV4dC1bMTBweF0gdGV4dC1wbGF0aW5hIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2VcIj5QcmVtaXVtIE1lc3NhZ2luZzwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNCBzcGFjZS15LTFcIj5cbiAgICAgICAge25hdkl0ZW1zLm1hcChpdGVtID0+IHtcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGxvY2F0aW9uLnBhdGhuYW1lID09PSBpdGVtLnBhdGg7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxMaW5rIFxuICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH0gXG4gICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGh9IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgcm91bmRlZC1yLXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke2lzQWN0aXZlID8gJ2JnLWdvbGQvMTAgdGV4dC1nb2xkIGJvcmRlci1sLTQgYm9yZGVyLWdvbGQnIDogJ3RleHQtcGxhdGluYS82MCBob3Zlcjp0ZXh0LWdvbGQgaG92ZXI6YmctZ29sZC81J31gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8aXRlbS5pY29uIHNpemU9ezIwfSBjbGFzc05hbWU9e2lzQWN0aXZlID8gJ3N0cm9rZS1nb2xkJyA6ICdzdHJva2UtcGxhdGluYS82MCd9IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtY2luemVsIHRleHQtc21cIj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L25hdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlci10IGJvcmRlci1nb2xkLzEwIHNwYWNlLXktNFwiPlxuICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIGlmICh3aW5kb3cuY29uZmlybSgnVGVtIGNlcnRlemEgcXVlIGRlc2VqYSBsaW1wYXIgdG9kb3Mgb3MgZGFkb3M/IElzc28gbsOjbyBwb2RlIHNlciBkZXNmZWl0by4nKSkge1xuICAgICAgICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLmNsZWFyKCk7XG4gICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LXJ1YnkvNDAgaG92ZXI6dGV4dC1ydWJ5IHRyYW5zaXRpb24tY29sb3JzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1sZWZ0XCJcbiAgICAgICAgPlxuICAgICAgICAgIExpbXBhciBTaXN0ZW1hXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmb250LW1vbm8gdGV4dC1bMTBweF0gdGV4dC1wbGF0aW5hLzMwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5cbiAgICAgICAgICA8c3Bhbj52Mi4wLjU8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1nb2xkLzQwXCI+UHJlbWl1bTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFpQndKO0FBakJ4SixTQUFTLE1BQU0sbUJBQW1CO0FBQ2xDLFNBQVMsaUJBQWlCLEtBQUssZUFBZSxhQUFxQjtBQUVuRSx3QkFBd0IsVUFBVTtBQUNoQyxRQUFNLFdBQVcsWUFBWTtBQUU3QixRQUFNLFdBQVc7QUFBQSxJQUNmLEVBQUUsTUFBTSxLQUFLLE1BQU0saUJBQWlCLE9BQU8sWUFBWTtBQUFBLElBQ3ZELEVBQUUsTUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFPLE9BQU87QUFBQSxJQUMxQyxFQUFFLE1BQU0sYUFBYSxNQUFNLGVBQWUsT0FBTyxZQUFZO0FBQUEsSUFDN0QsRUFBRSxNQUFNLFlBQVksTUFBTSxPQUFPLE9BQU8sV0FBVztBQUFBLEVBQ3JEO0FBRUEsU0FDRSx1QkFBQyxXQUFNLFdBQVUseUVBQ2Y7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwrQkFBQyxTQUFJLE9BQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLFdBQVUsYUFBWSxPQUFNLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGlDQUFDLFVBQUssR0FBRSwwQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDLEtBQTFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEw7QUFBQSxRQUM1TCx1QkFBQyxRQUFHLFdBQVUsK0dBQThHLHlCQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFJO0FBQUEsV0FGekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsa0VBQWlFLGlDQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStGO0FBQUEsU0FMakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1osbUJBQVMsSUFBSSxVQUFRO0FBQ3BCLFlBQU0sV0FBVyxTQUFTLGFBQWEsS0FBSztBQUM1QyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxJQUFJLEtBQUs7QUFBQSxVQUNULFdBQVcsOEVBQThFLFdBQVcsZ0RBQWdELGlEQUFpRDtBQUFBLFVBRXJNO0FBQUEsbUNBQUMsS0FBSyxNQUFMLEVBQVUsTUFBTSxJQUFJLFdBQVcsV0FBVyxnQkFBZ0IsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsVUFBSyxXQUFVLHVCQUF1QixlQUFLLFNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUE7QUFBQTtBQUFBLFFBTDdDLEtBQUs7QUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLElBRUosQ0FBQyxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTTtBQUNiLGdCQUFJLE9BQU8sUUFBUSwyRUFBMkUsR0FBRztBQUMvRixxQkFBTyxhQUFhLE1BQU07QUFDMUIscUJBQU8sU0FBUyxPQUFPO0FBQUEsWUFDekI7QUFBQSxVQUNGO0FBQUEsVUFDQSxXQUFVO0FBQUEsVUFDWDtBQUFBO0FBQUEsUUFSRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHFHQUNiO0FBQUEsK0JBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUNaLHVCQUFDLFVBQUssV0FBVSxnQkFBZSx1QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFdBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0E7QUFFSjsiLCJuYW1lcyI6W119