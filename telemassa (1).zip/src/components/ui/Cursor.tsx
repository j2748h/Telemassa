import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
export default function Cursor() {
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [outline, setOutline] = useState({ x: 0, y: 0 });
  useEffect(() => {
    const move = (e) => {
      setPos({ x: e.clientX, y: e.clientY });
      setTimeout(() => setOutline({ x: e.clientX, y: e.clientY }), 100);
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "cursor-dot", style: { transform: `translate(${pos.x}px, ${pos.y}px)` } }, void 0, false, {
      fileName: "/app/applet/src/components/ui/Cursor.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(motion.div, { className: "cursor-dot-outline", animate: { x: outline.x - 10, y: outline.y - 10 }, transition: { type: "spring", stiffness: 100, damping: 15 } }, void 0, false, {
      fileName: "/app/applet/src/components/ui/Cursor.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/ui/Cursor.tsx",
    lineNumber: 18,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkN1cnNvci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ21vdGlvbi9yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEN1cnNvcigpIHtcbiAgY29uc3QgW3Bvcywgc2V0UG9zXSA9IHVzZVN0YXRlKHsgeDogMCwgeTogMCB9KTtcbiAgY29uc3QgW291dGxpbmUsIHNldE91dGxpbmVdID0gdXNlU3RhdGUoeyB4OiAwLCB5OiAwIH0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbW92ZSA9IChlOiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICBzZXRQb3MoeyB4OiBlLmNsaWVudFgsIHk6IGUuY2xpZW50WSB9KTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0T3V0bGluZSh7IHg6IGUuY2xpZW50WCwgeTogZS5jbGllbnRZIH0pLCAxMDApO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG1vdmUpO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgbW92ZSk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImN1cnNvci1kb3RcIiBzdHlsZT17eyB0cmFuc2Zvcm06IGB0cmFuc2xhdGUoJHtwb3MueH1weCwgJHtwb3MueX1weClgIH19IC8+XG4gICAgICA8bW90aW9uLmRpdiBjbGFzc05hbWU9XCJjdXJzb3ItZG90LW91dGxpbmVcIiBhbmltYXRlPXt7IHg6IG91dGxpbmUueCAtIDEwLCB5OiBvdXRsaW5lLnkgLSAxMCB9fSB0cmFuc2l0aW9uPXt7IHR5cGU6ICdzcHJpbmcnLCBzdGlmZm5lc3M6IDEwMCwgZGFtcGluZzogMTUgfX0gLz5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBaUJJLG1CQUNFLGNBREY7QUFqQkosU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGNBQWM7QUFFdkIsd0JBQXdCLFNBQVM7QUFDL0IsUUFBTSxDQUFDLEtBQUssTUFBTSxJQUFJLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUM7QUFDN0MsUUFBTSxDQUFDLFNBQVMsVUFBVSxJQUFJLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUM7QUFFckQsWUFBVSxNQUFNO0FBQ2QsVUFBTSxPQUFPLENBQUMsTUFBa0I7QUFDOUIsYUFBTyxFQUFFLEdBQUcsRUFBRSxTQUFTLEdBQUcsRUFBRSxRQUFRLENBQUM7QUFDckMsaUJBQVcsTUFBTSxXQUFXLEVBQUUsR0FBRyxFQUFFLFNBQVMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxHQUFHLEdBQUc7QUFBQSxJQUNsRTtBQUNBLFdBQU8saUJBQWlCLGFBQWEsSUFBSTtBQUN6QyxXQUFPLE1BQU0sT0FBTyxvQkFBb0IsYUFBYSxJQUFJO0FBQUEsRUFDM0QsR0FBRyxDQUFDLENBQUM7QUFFTCxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFLFdBQVcsYUFBYSxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVGO0FBQUEsSUFDdkYsdUJBQUMsT0FBTyxLQUFQLEVBQVcsV0FBVSxzQkFBcUIsU0FBUyxFQUFFLEdBQUcsUUFBUSxJQUFJLElBQUksR0FBRyxRQUFRLElBQUksR0FBRyxHQUFHLFlBQVksRUFBRSxNQUFNLFVBQVUsV0FBVyxLQUFLLFNBQVMsR0FBRyxLQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJKO0FBQUEsT0FGN0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7IiwibmFtZXMiOltdfQ==