import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { X, Star } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
export default function Popup({ isOpen, onClose, title, subtitle, children }) {
  return /* @__PURE__ */ jsxDEV(AnimatePresence, { children: isOpen && /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        onClick: onClose,
        className: "fixed inset-0 bg-black/80 backdrop-blur-[12px] z-50"
      },
      void 0,
      false,
      {
        fileName: "/app/applet/src/components/ui/Popup.tsx",
        lineNumber: 18,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0, scale: 0.94 },
        animate: { opacity: 1, scale: 1 },
        exit: { opacity: 0, scale: 0.94 },
        transition: { duration: 0.25, ease: [0.34, 1.56, 0.64, 1] },
        className: "fixed inset-0 z-50 flex items-center justify-center p-4",
        children: /* @__PURE__ */ jsxDEV("div", { className: "glass-card w-full max-w-2xl overflow-hidden rounded-[24px] relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.05),transparent)]" }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Popup.tsx",
            lineNumber: 33,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-8 border-b border-gold/10 flex justify-between items-start relative", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-gold/10 rounded-full border border-gold/20", children: /* @__PURE__ */ jsxDEV(Star, { className: "stroke-gold", size: 24 }, void 0, false, {
                fileName: "/app/applet/src/components/ui/Popup.tsx",
                lineNumber: 37,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "/app/applet/src/components/ui/Popup.tsx",
                lineNumber: 36,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "font-serif text-2xl text-champagne", children: title }, void 0, false, {
                  fileName: "/app/applet/src/components/ui/Popup.tsx",
                  lineNumber: 40,
                  columnNumber: 21
                }, this),
                subtitle && /* @__PURE__ */ jsxDEV("p", { className: "font-sans text-xs text-platina mt-1", children: subtitle }, void 0, false, {
                  fileName: "/app/applet/src/components/ui/Popup.tsx",
                  lineNumber: 41,
                  columnNumber: 34
                }, this)
              ] }, void 0, true, {
                fileName: "/app/applet/src/components/ui/Popup.tsx",
                lineNumber: 39,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "/app/applet/src/components/ui/Popup.tsx",
              lineNumber: 35,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: onClose, className: "text-platina/40 hover:text-gold transition-all", children: /* @__PURE__ */ jsxDEV(X, { size: 24 }, void 0, false, {
              fileName: "/app/applet/src/components/ui/Popup.tsx",
              lineNumber: 44,
              columnNumber: 102
            }, this) }, void 0, false, {
              fileName: "/app/applet/src/components/ui/Popup.tsx",
              lineNumber: 44,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/components/ui/Popup.tsx",
            lineNumber: 34,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Popup.tsx",
            lineNumber: 46,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/ui/Popup.tsx",
          lineNumber: 32,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "/app/applet/src/components/ui/Popup.tsx",
        lineNumber: 25,
        columnNumber: 11
      },
      this
    )
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/ui/Popup.tsx",
    lineNumber: 17,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/app/applet/src/components/ui/Popup.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlBvcHVwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgWCwgU3RhciB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ21vdGlvbi9yZWFjdCc7XG5cbmludGVyZmFjZSBQb3B1cFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICB0aXRsZTogc3RyaW5nO1xuICBzdWJ0aXRsZT86IHN0cmluZztcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUG9wdXAoeyBpc09wZW4sIG9uQ2xvc2UsIHRpdGxlLCBzdWJ0aXRsZSwgY2hpbGRyZW4gfTogUG9wdXBQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICB7aXNPcGVuICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8bW90aW9uLmRpdiBcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItWzEycHhdIHotNTBcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPG1vdGlvbi5kaXYgXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk0IH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk0IH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjI1LCBlYXNlOiBbMC4zNCwgMS41NiwgMC42NCwgMV0gfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCB3LWZ1bGwgbWF4LXctMnhsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLVsyNHB4XSByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctW3JhZGlhbC1ncmFkaWVudChjaXJjbGVfYXRfdG9wX3JpZ2h0LHJnYmEoMjEyLDE3NSw1NSwwLjA1KSx0cmFuc3BhcmVudCldXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggYm9yZGVyLWIgYm9yZGVyLWdvbGQvMTAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1nb2xkLzEwIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdvbGQvMjBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwic3Ryb2tlLWdvbGRcIiBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VyaWYgdGV4dC0yeGwgdGV4dC1jaGFtcGFnbmVcIj57dGl0bGV9PC9oMj5cbiAgICAgICAgICAgICAgICAgICAge3N1YnRpdGxlICYmIDxwIGNsYXNzTmFtZT1cImZvbnQtc2FucyB0ZXh0LXhzIHRleHQtcGxhdGluYSBtdC0xXCI+e3N1YnRpdGxlfTwvcD59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cInRleHQtcGxhdGluYS80MCBob3Zlcjp0ZXh0LWdvbGQgdHJhbnNpdGlvbi1hbGxcIj48WCBzaXplPXsyNH0gLz48L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHJlbGF0aXZlXCI+e2NoaWxkcmVufTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiJBQWdCUSxtQkFDRSxjQURGO0FBZlIsU0FBUyxHQUFHLFlBQVk7QUFDeEIsU0FBUyxRQUFRLHVCQUF1QjtBQVV4Qyx3QkFBd0IsTUFBTSxFQUFFLFFBQVEsU0FBUyxPQUFPLFVBQVUsU0FBUyxHQUFlO0FBQ3hGLFNBQ0UsdUJBQUMsbUJBQ0Usb0JBQ0MsbUNBQ0U7QUFBQTtBQUFBLE1BQUMsT0FBTztBQUFBLE1BQVA7QUFBQSxRQUNDLFNBQVMsRUFBRSxTQUFTLEVBQUU7QUFBQSxRQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0FBQUEsUUFDdEIsTUFBTSxFQUFFLFNBQVMsRUFBRTtBQUFBLFFBQ25CLFNBQVM7QUFBQSxRQUNULFdBQVU7QUFBQTtBQUFBLE1BTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUE7QUFBQSxJQUNBO0FBQUEsTUFBQyxPQUFPO0FBQUEsTUFBUDtBQUFBLFFBQ0MsU0FBUyxFQUFFLFNBQVMsR0FBRyxPQUFPLEtBQUs7QUFBQSxRQUNuQyxTQUFTLEVBQUUsU0FBUyxHQUFHLE9BQU8sRUFBRTtBQUFBLFFBQ2hDLE1BQU0sRUFBRSxTQUFTLEdBQUcsT0FBTyxLQUFLO0FBQUEsUUFDaEMsWUFBWSxFQUFFLFVBQVUsTUFBTSxNQUFNLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQyxFQUFFO0FBQUEsUUFDMUQsV0FBVTtBQUFBLFFBRVYsaUNBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThHO0FBQUEsVUFDOUcsdUJBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLFFBQUssV0FBVSxlQUFjLE1BQU0sTUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxzQ0FBc0MsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBEO0FBQUEsZ0JBQ3pELFlBQVksdUJBQUMsT0FBRSxXQUFVLHVDQUF1QyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxtQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFlBQU8sU0FBUyxTQUFTLFdBQVUsa0RBQWlELGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWEsS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0c7QUFBQSxlQVZ0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCLFlBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFkMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUE7QUFBQSxNQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1QkE7QUFBQSxPQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0NBLEtBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQ0E7QUFFSjsiLCJuYW1lcyI6W119