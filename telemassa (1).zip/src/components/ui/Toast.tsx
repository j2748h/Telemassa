import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport1_react["useState"]; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"];
import { motion, AnimatePresence } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
import { CheckCircle, XCircle, AlertTriangle, Info } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
const ToastContext = createContext({ addToast: (t) => {
} });
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  const addToast = (t) => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((t2) => t2.id !== id)), 4e3);
  };
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value: { addToast }, children: [
    children,
    /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-8 right-8 z-[9999] space-y-4", children: /* @__PURE__ */ jsxDEV(AnimatePresence, { children: toasts.map((t) => /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { opacity: 0, x: 50 },
        animate: { opacity: 1, x: 0 },
        exit: { opacity: 0, x: 50 },
        className: `glass-card p-5 flex items-center gap-5 border-l-4 rounded-[16px] ${t.type === "success" ? "border-l-emerald" : t.type === "error" ? "border-l-ruby" : t.type === "warning" ? "border-l-amber" : "border-l-gold"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: `p-2 rounded-full ${t.type === "success" ? "bg-emerald/10" : t.type === "error" ? "bg-ruby/10" : t.type === "warning" ? "bg-amber/10" : "bg-gold/10"}`, children: t.type === "success" ? /* @__PURE__ */ jsxDEV(CheckCircle, { className: "stroke-emerald", size: 20 }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 26,
            columnNumber: 41
          }, this) : t.type === "error" ? /* @__PURE__ */ jsxDEV(XCircle, { className: "stroke-ruby", size: 20 }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 26,
            columnNumber: 117
          }, this) : t.type === "warning" ? /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "stroke-amber", size: 20 }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 26,
            columnNumber: 188
          }, this) : /* @__PURE__ */ jsxDEV(Info, { className: "stroke-gold", size: 20 }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 26,
            columnNumber: 243
          }, this) }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 25,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-champagne font-cinzel font-semibold", children: t.title }, void 0, false, {
              fileName: "/app/applet/src/components/ui/Toast.tsx",
              lineNumber: 29,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-platina/70 text-xs font-sans mt-0.5", children: t.message }, void 0, false, {
              fileName: "/app/applet/src/components/ui/Toast.tsx",
              lineNumber: 30,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 28,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 h-1 bg-[linear-gradient(to_right,#D4AF37,#F5D76E)] rounded-full animate-progress" }, void 0, false, {
            fileName: "/app/applet/src/components/ui/Toast.tsx",
            lineNumber: 32,
            columnNumber: 15
          }, this)
        ]
      },
      t.id,
      true,
      {
        fileName: "/app/applet/src/components/ui/Toast.tsx",
        lineNumber: 23,
        columnNumber: 13
      },
      this
    )) }, void 0, false, {
      fileName: "/app/applet/src/components/ui/Toast.tsx",
      lineNumber: 21,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/ui/Toast.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/ui/Toast.tsx",
    lineNumber: 18,
    columnNumber: 5
  }, this);
};
export const useToast = () => useContext(ToastContext);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRvYXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiwgQW5pbWF0ZVByZXNlbmNlIH0gZnJvbSAnbW90aW9uL3JlYWN0JztcbmltcG9ydCB7IENoZWNrQ2lyY2xlLCBYQ2lyY2xlLCBBbGVydFRyaWFuZ2xlLCBJbmZvIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxudHlwZSBUb2FzdFR5cGUgPSAnc3VjY2VzcycgfCAnZXJyb3InIHwgJ3dhcm5pbmcnIHwgJ2luZm8nO1xuaW50ZXJmYWNlIFRvYXN0IHsgaWQ6IHN0cmluZzsgdHlwZTogVG9hc3RUeXBlOyB0aXRsZTogc3RyaW5nOyBtZXNzYWdlOiBzdHJpbmc7IH1cblxuY29uc3QgVG9hc3RDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7IGFkZFRvYXN0OiAodDogT21pdDxUb2FzdCwgJ2lkJz4pID0+IHt9IH0pO1xuXG5leHBvcnQgY29uc3QgVG9hc3RQcm92aWRlciA9ICh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSA9PiB7XG4gIGNvbnN0IFt0b2FzdHMsIHNldFRvYXN0c10gPSB1c2VTdGF0ZTxUb2FzdFtdPihbXSk7XG4gIGNvbnN0IGFkZFRvYXN0ID0gKHQ6IE9taXQ8VG9hc3QsICdpZCc+KSA9PiB7XG4gICAgY29uc3QgaWQgPSBEYXRlLm5vdygpLnRvU3RyaW5nKCk7XG4gICAgc2V0VG9hc3RzKHByZXYgPT4gWy4uLnByZXYsIHsgLi4udCwgaWQgfV0pO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3RzKHByZXYgPT4gcHJldi5maWx0ZXIodCA9PiB0LmlkICE9PSBpZCkpLCA0MDAwKTtcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8VG9hc3RDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGFkZFRvYXN0IH19PlxuICAgICAge2NoaWxkcmVufVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tOCByaWdodC04IHotWzk5OTldIHNwYWNlLXktNFwiPlxuICAgICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICAgIHt0b2FzdHMubWFwKHQgPT4gKFxuICAgICAgICAgICAgPG1vdGlvbi5kaXYga2V5PXt0LmlkfSBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHg6IDUwIH19IGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeDogMCB9fSBleGl0PXt7IG9wYWNpdHk6IDAsIHg6IDUwIH19IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BnbGFzcy1jYXJkIHAtNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBib3JkZXItbC00IHJvdW5kZWQtWzE2cHhdICR7dC50eXBlID09PSAnc3VjY2VzcycgPyAnYm9yZGVyLWwtZW1lcmFsZCcgOiB0LnR5cGUgPT09ICdlcnJvcicgPyAnYm9yZGVyLWwtcnVieScgOiB0LnR5cGUgPT09ICd3YXJuaW5nJyA/ICdib3JkZXItbC1hbWJlcicgOiAnYm9yZGVyLWwtZ29sZCd9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtZnVsbCAke3QudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJ2JnLWVtZXJhbGQvMTAnIDogdC50eXBlID09PSAnZXJyb3InID8gJ2JnLXJ1YnkvMTAnIDogdC50eXBlID09PSAnd2FybmluZycgPyAnYmctYW1iZXIvMTAnIDogJ2JnLWdvbGQvMTAnfWB9PlxuICAgICAgICAgICAgICAgIHt0LnR5cGUgPT09ICdzdWNjZXNzJyA/IDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJzdHJva2UtZW1lcmFsZFwiIHNpemU9ezIwfSAvPiA6IHQudHlwZSA9PT0gJ2Vycm9yJyA/IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInN0cm9rZS1ydWJ5XCIgc2l6ZT17MjB9IC8+IDogdC50eXBlID09PSAnd2FybmluZycgPyA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJzdHJva2UtYW1iZXJcIiBzaXplPXsyMH0gLz4gOiA8SW5mbyBjbGFzc05hbWU9XCJzdHJva2UtZ29sZFwiIHNpemU9ezIwfSAvPn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtY2hhbXBhZ25lIGZvbnQtY2luemVsIGZvbnQtc2VtaWJvbGRcIj57dC50aXRsZX08L2g0PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcGxhdGluYS83MCB0ZXh0LXhzIGZvbnQtc2FucyBtdC0wLjVcIj57dC5tZXNzYWdlfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIGgtMSBiZy1bbGluZWFyLWdyYWRpZW50KHRvX3JpZ2h0LCNENEFGMzcsI0Y1RDc2RSldIHJvdW5kZWQtZnVsbCBhbmltYXRlLXByb2dyZXNzXCIgLz5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICAgICA8L2Rpdj5cbiAgICA8L1RvYXN0Q29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG5leHBvcnQgY29uc3QgdXNlVG9hc3QgPSAoKSA9PiB1c2VDb250ZXh0KFRvYXN0Q29udGV4dCk7XG4iXSwibWFwcGluZ3MiOiJBQXlCd0M7QUF6QnhDLFNBQWdCLFVBQXFCLGVBQWUsa0JBQWtCO0FBQ3RFLFNBQVMsUUFBUSx1QkFBdUI7QUFDeEMsU0FBUyxhQUFhLFNBQVMsZUFBZSxZQUFZO0FBSzFELE1BQU0sZUFBZSxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQXlCO0FBQUMsRUFBRSxDQUFDO0FBRXRFLGFBQU0sZ0JBQWdCLENBQUMsRUFBRSxTQUFTLE1BQXFDO0FBQzVFLFFBQU0sQ0FBQyxRQUFRLFNBQVMsSUFBSSxTQUFrQixDQUFDLENBQUM7QUFDaEQsUUFBTSxXQUFXLENBQUMsTUFBeUI7QUFDekMsVUFBTSxLQUFLLEtBQUssSUFBSSxFQUFFLFNBQVM7QUFDL0IsY0FBVSxVQUFRLENBQUMsR0FBRyxNQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLGVBQVcsTUFBTSxVQUFVLFVBQVEsS0FBSyxPQUFPLENBQUFBLE9BQUtBLEdBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxHQUFJO0FBQUEsRUFDekU7QUFDQSxTQUNFLHVCQUFDLGFBQWEsVUFBYixFQUFzQixPQUFPLEVBQUUsU0FBUyxHQUN0QztBQUFBO0FBQUEsSUFDRCx1QkFBQyxTQUFJLFdBQVUsNkNBQ2IsaUNBQUMsbUJBQ0UsaUJBQU8sSUFBSSxPQUNWO0FBQUEsTUFBQyxPQUFPO0FBQUEsTUFBUDtBQUFBLFFBQXNCLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxHQUFHO0FBQUEsUUFBRyxTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsRUFBRTtBQUFBLFFBQUcsTUFBTSxFQUFFLFNBQVMsR0FBRyxHQUFHLEdBQUc7QUFBQSxRQUM5RyxXQUFXLG9FQUFvRSxFQUFFLFNBQVMsWUFBWSxxQkFBcUIsRUFBRSxTQUFTLFVBQVUsa0JBQWtCLEVBQUUsU0FBUyxZQUFZLG1CQUFtQixlQUFlO0FBQUEsUUFDM047QUFBQSxpQ0FBQyxTQUFJLFdBQVcsb0JBQW9CLEVBQUUsU0FBUyxZQUFZLGtCQUFrQixFQUFFLFNBQVMsVUFBVSxlQUFlLEVBQUUsU0FBUyxZQUFZLGdCQUFnQixZQUFZLElBQ2pLLFlBQUUsU0FBUyxZQUFZLHVCQUFDLGVBQVksV0FBVSxrQkFBaUIsTUFBTSxNQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRCxJQUFLLEVBQUUsU0FBUyxVQUFVLHVCQUFDLFdBQVEsV0FBVSxlQUFjLE1BQU0sTUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkMsSUFBSyxFQUFFLFNBQVMsWUFBWSx1QkFBQyxpQkFBYyxXQUFVLGdCQUFlLE1BQU0sTUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0QsSUFBSyx1QkFBQyxRQUFLLFdBQVUsZUFBYyxNQUFNLE1BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDLEtBRDVRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNENBQTRDLFlBQUUsU0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRSx1QkFBQyxPQUFFLFdBQVUsNENBQTRDLFlBQUUsV0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxlQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsK0dBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQTtBQUFBO0FBQUEsTUFUNUcsRUFBRTtBQUFBLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVQSxDQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUNPLGFBQU0sV0FBVyxNQUFNLFdBQVcsWUFBWTsiLCJuYW1lcyI6WyJ0Il19