import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
export default function SearchOverlay({ isOpen, onClose }) {
  const [query, setQuery] = useState("");
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);
  return /* @__PURE__ */ jsxDEV(AnimatePresence, { children: isOpen && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "fixed inset-0 z-[9999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "glass-card w-full max-w-2xl p-6 space-y-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 border-b border-border-gold pb-4", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "text-gold" }, void 0, false, {
        fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
        lineNumber: 20,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("input", { autoFocus: true, value: query, onChange: (e) => setQuery(e.target.value), placeholder: "Buscar bots, mensagens, clientes...", className: "flex-1 bg-transparent text-text-main text-xl focus:outline-none" }, void 0, false, {
        fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
        lineNumber: 21,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: onClose, children: /* @__PURE__ */ jsxDEV(X, { className: "text-text-muted hover:text-text-main" }, void 0, false, {
        fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
        lineNumber: 22,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
        lineNumber: 22,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
      lineNumber: 19,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-text-muted text-sm italic", children: [
      'Resultados para "',
      query,
      '" aparecerão aqui...'
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
      lineNumber: 24,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
    lineNumber: 18,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
    lineNumber: 17,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/app/applet/src/components/ui/SearchOverlay.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNlYXJjaE92ZXJsYXkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTZWFyY2gsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdtb3Rpb24vcmVhY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZWFyY2hPdmVybGF5KHsgaXNPcGVuLCBvbkNsb3NlIH06IHsgaXNPcGVuOiBib29sZWFuLCBvbkNsb3NlOiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHsgaWYgKGUua2V5ID09PSAnRXNjYXBlJykgb25DbG9zZSgpOyB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtvbkNsb3NlXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgIDxtb3Rpb24uZGl2IGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fSBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX0gZXhpdD17eyBvcGFjaXR5OiAwIH19IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OV0gYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgdy1mdWxsIG1heC13LTJ4bCBwLTYgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IGJvcmRlci1iIGJvcmRlci1ib3JkZXItZ29sZCBwYi00XCI+XG4gICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidGV4dC1nb2xkXCIgLz5cbiAgICAgICAgICAgICAgPGlucHV0IGF1dG9Gb2N1cyB2YWx1ZT17cXVlcnl9IG9uQ2hhbmdlPXtlID0+IHNldFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJCdXNjYXIgYm90cywgbWVuc2FnZW5zLCBjbGllbnRlcy4uLlwiIGNsYXNzTmFtZT1cImZsZXgtMSBiZy10cmFuc3BhcmVudCB0ZXh0LXRleHQtbWFpbiB0ZXh0LXhsIGZvY3VzOm91dGxpbmUtbm9uZVwiIC8+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0+PFggY2xhc3NOYW1lPVwidGV4dC10ZXh0LW11dGVkIGhvdmVyOnRleHQtdGV4dC1tYWluXCIgLz48L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXRleHQtbXV0ZWQgdGV4dC1zbSBpdGFsaWNcIj5SZXN1bHRhZG9zIHBhcmEgXCJ7cXVlcnl9XCIgYXBhcmVjZXLDo28gYXF1aS4uLjwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICApfVxuICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFtQmM7QUFuQmQsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxTQUFTLFFBQVEsU0FBUztBQUMxQixTQUFTLFFBQVEsdUJBQXVCO0FBRXhDLHdCQUF3QixjQUFjLEVBQUUsUUFBUSxRQUFRLEdBQTZDO0FBQ25HLFFBQU0sQ0FBQyxPQUFPLFFBQVEsSUFBSSxTQUFTLEVBQUU7QUFFckMsWUFBVSxNQUFNO0FBQ2QsVUFBTSxnQkFBZ0IsQ0FBQyxNQUFxQjtBQUFFLFVBQUksRUFBRSxRQUFRLFNBQVUsU0FBUTtBQUFBLElBQUc7QUFDakYsV0FBTyxpQkFBaUIsV0FBVyxhQUFhO0FBQ2hELFdBQU8sTUFBTSxPQUFPLG9CQUFvQixXQUFXLGFBQWE7QUFBQSxFQUNsRSxHQUFHLENBQUMsT0FBTyxDQUFDO0FBRVosU0FDRSx1QkFBQyxtQkFDRSxvQkFDQyx1QkFBQyxPQUFPLEtBQVAsRUFBVyxTQUFTLEVBQUUsU0FBUyxFQUFFLEdBQUcsU0FBUyxFQUFFLFNBQVMsRUFBRSxHQUFHLE1BQU0sRUFBRSxTQUFTLEVBQUUsR0FBRyxXQUFVLDRGQUM1RixpQ0FBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSw2QkFBQyxVQUFPLFdBQVUsZUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLE1BQzlCLHVCQUFDLFdBQU0sV0FBUyxNQUFDLE9BQU8sT0FBTyxVQUFVLE9BQUssU0FBUyxFQUFFLE9BQU8sS0FBSyxHQUFHLGFBQVksdUNBQXNDLFdBQVUscUVBQXBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc007QUFBQSxNQUN0TSx1QkFBQyxZQUFPLFNBQVMsU0FBUyxpQ0FBQyxLQUFFLFdBQVUsMENBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsU0FIbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsa0NBQWlDO0FBQUE7QUFBQSxNQUFrQjtBQUFBLE1BQU07QUFBQSxTQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRGO0FBQUEsT0FOOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBLEtBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBO0FBRUo7IiwibmFtZXMiOltdfQ==