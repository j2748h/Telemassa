import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54c12b95"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=54c12b95"; const useState = __vite__cjsImport1_react["useState"];
import { useLocalStorage } from "/src/hooks/useStorage.ts";
import { Trash2, Plus, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=54c12b95";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/motion_react.js?v=54c12b95";
import Popup from "/src/components/ui/Popup.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
export default function BotManager() {
  const [bots, setBots] = useLocalStorage("bots", []);
  const [messages] = useLocalStorage("messages", []);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [editingBot, setEditingBot] = useState(null);
  const [formData, setFormData] = useState({ name: "", username: "", token: "" });
  const [isValidating, setIsValidating] = useState(false);
  const { addToast } = useToast();
  const validateToken = async (token) => {
    setIsValidating(true);
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const data = await response.json();
      if (data.ok) {
        setFormData((prev) => ({ ...prev, name: data.result.first_name, username: data.result.username }));
        addToast({ type: "success", title: "Bot Validado", message: `Bot ${data.result.first_name} conectado!` });
        setIsValidating(false);
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    setIsValidating(false);
    addToast({ type: "error", title: "Token Inválido", message: "Não foi possível conectar ao bot." });
    return false;
  };
  const handleSave = async () => {
    if (!await validateToken(formData.token)) return;
    if (editingBot) {
      setBots(bots.map((b) => b.id === editingBot.id ? { ...b, ...formData } : b));
    } else {
      setBots([...bots, { id: Date.now().toString(), ...formData, status: "active", createdAt: (/* @__PURE__ */ new Date()).toISOString() }]);
    }
    setIsPopupOpen(false);
    addToast({ type: "success", title: "Bot Salvo", message: "Configurações atualizadas." });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-12", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "font-serif text-4xl text-champagne", children: "Bots Gerenciados" }, void 0, false, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: () => {
        setEditingBot(null);
        setFormData({ name: "", username: "", token: "" });
        setIsPopupOpen(true);
      }, className: "btn-primary flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Plus, { size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 53,
          columnNumber: 11
        }, this),
        " Adicionar Bot"
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8", children: /* @__PURE__ */ jsxDEV(AnimatePresence, { children: bots.map((bot, index) => /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, scale: 0.9 }, transition: { delay: index * 0.08 }, className: "glass-card p-8 flex flex-col gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center text-gold font-serif text-2xl", children: bot.name[0] }, void 0, false, {
            fileName: "/app/applet/src/components/BotManager.tsx",
            lineNumber: 63,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "font-serif text-xl text-champagne", children: bot.name }, void 0, false, {
              fileName: "/app/applet/src/components/BotManager.tsx",
              lineNumber: 65,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-mono text-xs text-platina/60", children: [
              "@",
              bot.username
            ] }, void 0, true, {
              fileName: "/app/applet/src/components/BotManager.tsx",
              lineNumber: 66,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "/app/applet/src/components/BotManager.tsx",
            lineNumber: 64,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 62,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `w-3 h-3 rounded-full ${bot.status === "active" ? "bg-emerald" : "bg-ruby"}` }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 69,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 61,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[11px] font-mono text-platina/40 border-t border-gold/10 pt-6", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Criado: ",
          new Date(bot.createdAt || Date.now()).toLocaleDateString()
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 72,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          "Msgs: ",
          messages.filter((m) => m.botId === bot.id).length
        ] }, void 0, true, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 73,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 71,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => {
          setEditingBot(bot);
          setFormData({ name: bot.name, username: bot.username, token: bot.token });
          setIsPopupOpen(true);
        }, className: "btn-ghost flex-1", children: "Editar" }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 76,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setBots(bots.filter((b) => b.id !== bot.id)), className: "p-3 bg-ruby/10 text-ruby border border-ruby/30 rounded-full hover:bg-ruby/20 transition-all", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 77,
          columnNumber: 188
        }, this) }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 77,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 75,
        columnNumber: 15
      }, this)
    ] }, bot.id, true, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 60,
      columnNumber: 13
    }, this)) }, void 0, false, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 58,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Popup, { isOpen: isPopupOpen, onClose: () => setIsPopupOpen(false), title: editingBot ? "Editar Bot" : "Adicionar Bot", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Nome do Bot", value: formData.name, onChange: (e) => setFormData({ ...formData, name: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 86,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Username do Bot", value: formData.username, onChange: (e) => setFormData({ ...formData, username: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 87,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Token do Bot", value: formData.token, onChange: (e) => setFormData({ ...formData, token: e.target.value }), className: "w-full" }, void 0, false, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 88,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleSave, disabled: isValidating, className: "btn-primary w-full flex items-center justify-center gap-2", children: isValidating ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Loader2, { className: "animate-spin", size: 18 }, void 0, false, {
          fileName: "/app/applet/src/components/BotManager.tsx",
          lineNumber: 90,
          columnNumber: 31
        }, this),
        " Verificando..."
      ] }, void 0, true, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 90,
        columnNumber: 29
      }, this) : "Salvar Bot" }, void 0, false, {
        fileName: "/app/applet/src/components/BotManager.tsx",
        lineNumber: 89,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 85,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/app/applet/src/components/BotManager.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/app/applet/src/components/BotManager.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkJvdE1hbmFnZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTG9jYWxTdG9yYWdlIH0gZnJvbSAnLi4vaG9va3MvdXNlU3RvcmFnZSc7XG5pbXBvcnQgeyBCb3QgYXMgQm90VHlwZSwgTWVzc2FnZSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IFRyYXNoMiwgRWRpdDIsIFBsdXMsIExvYWRlcjIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdtb3Rpb24vcmVhY3QnO1xuaW1wb3J0IFBvcHVwIGZyb20gJy4vdWkvUG9wdXAnO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tICcuL3VpL1RvYXN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQm90TWFuYWdlcigpIHtcbiAgY29uc3QgW2JvdHMsIHNldEJvdHNdID0gdXNlTG9jYWxTdG9yYWdlPEJvdFR5cGVbXT4oJ2JvdHMnLCBbXSk7XG4gIGNvbnN0IFttZXNzYWdlc10gPSB1c2VMb2NhbFN0b3JhZ2U8TWVzc2FnZVtdPignbWVzc2FnZXMnLCBbXSk7XG4gIGNvbnN0IFtpc1BvcHVwT3Blbiwgc2V0SXNQb3B1cE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdGluZ0JvdCwgc2V0RWRpdGluZ0JvdF0gPSB1c2VTdGF0ZTxCb3RUeXBlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoeyBuYW1lOiAnJywgdXNlcm5hbWU6ICcnLCB0b2tlbjogJycgfSk7XG4gIGNvbnN0IFtpc1ZhbGlkYXRpbmcsIHNldElzVmFsaWRhdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHsgYWRkVG9hc3QgfSA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgdmFsaWRhdGVUb2tlbiA9IGFzeW5jICh0b2tlbjogc3RyaW5nKSA9PiB7XG4gICAgc2V0SXNWYWxpZGF0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGBodHRwczovL2FwaS50ZWxlZ3JhbS5vcmcvYm90JHt0b2tlbn0vZ2V0TWVgKTtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICBpZiAoZGF0YS5vaykge1xuICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIG5hbWU6IGRhdGEucmVzdWx0LmZpcnN0X25hbWUsIHVzZXJuYW1lOiBkYXRhLnJlc3VsdC51c2VybmFtZSB9KSk7XG4gICAgICAgIGFkZFRvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0JvdCBWYWxpZGFkbycsIG1lc3NhZ2U6IGBCb3QgJHtkYXRhLnJlc3VsdC5maXJzdF9uYW1lfSBjb25lY3RhZG8hYCB9KTtcbiAgICAgICAgc2V0SXNWYWxpZGF0aW5nKGZhbHNlKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkgeyBcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7IFxuICAgIH1cbiAgICBzZXRJc1ZhbGlkYXRpbmcoZmFsc2UpO1xuICAgIGFkZFRvYXN0KHsgdHlwZTogJ2Vycm9yJywgdGl0bGU6ICdUb2tlbiBJbnbDoWxpZG8nLCBtZXNzYWdlOiAnTsOjbyBmb2kgcG9zc8OtdmVsIGNvbmVjdGFyIGFvIGJvdC4nIH0pO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYXdhaXQgdmFsaWRhdGVUb2tlbihmb3JtRGF0YS50b2tlbikpIHJldHVybjtcbiAgICBpZiAoZWRpdGluZ0JvdCkge1xuICAgICAgc2V0Qm90cyhib3RzLm1hcChiID0+IGIuaWQgPT09IGVkaXRpbmdCb3QuaWQgPyB7IC4uLmIsIC4uLmZvcm1EYXRhIH0gOiBiKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEJvdHMoWy4uLmJvdHMsIHsgaWQ6IERhdGUubm93KCkudG9TdHJpbmcoKSwgLi4uZm9ybURhdGEsIHN0YXR1czogJ2FjdGl2ZScsIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH1dKTtcbiAgICB9XG4gICAgc2V0SXNQb3B1cE9wZW4oZmFsc2UpO1xuICAgIGFkZFRvYXN0KHsgdHlwZTogJ3N1Y2Nlc3MnLCB0aXRsZTogJ0JvdCBTYWx2bycsIG1lc3NhZ2U6ICdDb25maWd1cmHDp8O1ZXMgYXR1YWxpemFkYXMuJyB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xMlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VyaWYgdGV4dC00eGwgdGV4dC1jaGFtcGFnbmVcIj5Cb3RzIEdlcmVuY2lhZG9zPC9oMj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldEVkaXRpbmdCb3QobnVsbCk7IHNldEZvcm1EYXRhKHsgbmFtZTogJycsIHVzZXJuYW1lOiAnJywgdG9rZW46ICcnIH0pOyBzZXRJc1BvcHVwT3Blbih0cnVlKTsgfX0gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnkgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8UGx1cyBzaXplPXsxOH0gLz4gQWRpY2lvbmFyIEJvdFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cbiAgICAgICAgPEFuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAgICB7Ym90cy5tYXAoKGJvdCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2IGtleT17Ym90LmlkfSBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19IGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fSBleGl0PXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjkgfX0gdHJhbnNpdGlvbj17eyBkZWxheTogaW5kZXggKiAwLjA4IH19IGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgcC04IGZsZXggZmxleC1jb2wgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC01XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctZ29sZC8xMCBib3JkZXIgYm9yZGVyLWdvbGQvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1nb2xkIGZvbnQtc2VyaWYgdGV4dC0yeGxcIj57Ym90Lm5hbWVbMF19PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlcmlmIHRleHQteGwgdGV4dC1jaGFtcGFnbmVcIj57Ym90Lm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LXBsYXRpbmEvNjBcIj5Ae2JvdC51c2VybmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMyBoLTMgcm91bmRlZC1mdWxsICR7Ym90LnN0YXR1cyA9PT0gJ2FjdGl2ZScgPyAnYmctZW1lcmFsZCcgOiAnYmctcnVieSd9YH0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtcGxhdGluYS80MCBib3JkZXItdCBib3JkZXItZ29sZC8xMCBwdC02XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q3JpYWRvOiB7bmV3IERhdGUoYm90LmNyZWF0ZWRBdCB8fCBEYXRlLm5vdygpKS50b0xvY2FsZURhdGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+TXNnczoge21lc3NhZ2VzLmZpbHRlcihtID0+IG0uYm90SWQgPT09IGJvdC5pZCkubGVuZ3RofTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4geyBzZXRFZGl0aW5nQm90KGJvdCk7IHNldEZvcm1EYXRhKHsgbmFtZTogYm90Lm5hbWUsIHVzZXJuYW1lOiBib3QudXNlcm5hbWUsIHRva2VuOiBib3QudG9rZW4gfSk7IHNldElzUG9wdXBPcGVuKHRydWUpOyB9fSBjbGFzc05hbWU9XCJidG4tZ2hvc3QgZmxleC0xXCI+RWRpdGFyPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRCb3RzKGJvdHMuZmlsdGVyKGIgPT4gYi5pZCAhPT0gYm90LmlkKSl9IGNsYXNzTmFtZT1cInAtMyBiZy1ydWJ5LzEwIHRleHQtcnVieSBib3JkZXIgYm9yZGVyLXJ1YnkvMzAgcm91bmRlZC1mdWxsIGhvdmVyOmJnLXJ1YnkvMjAgdHJhbnNpdGlvbi1hbGxcIj48VHJhc2gyIHNpemU9ezE4fSAvPjwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPFBvcHVwIGlzT3Blbj17aXNQb3B1cE9wZW59IG9uQ2xvc2U9eygpID0+IHNldElzUG9wdXBPcGVuKGZhbHNlKX0gdGl0bGU9e2VkaXRpbmdCb3QgPyBcIkVkaXRhciBCb3RcIiA6IFwiQWRpY2lvbmFyIEJvdFwifT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk5vbWUgZG8gQm90XCIgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9IG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHsuLi5mb3JtRGF0YSwgbmFtZTogZS50YXJnZXQudmFsdWV9KX0gY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIlVzZXJuYW1lIGRvIEJvdFwiIHZhbHVlPXtmb3JtRGF0YS51c2VybmFtZX0gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCB1c2VybmFtZTogZS50YXJnZXQudmFsdWV9KX0gY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIlRva2VuIGRvIEJvdFwiIHZhbHVlPXtmb3JtRGF0YS50b2tlbn0gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCB0b2tlbjogZS50YXJnZXQudmFsdWV9KX0gY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVNhdmV9IGRpc2FibGVkPXtpc1ZhbGlkYXRpbmd9IGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5IHctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAge2lzVmFsaWRhdGluZyA/IDw+PExvYWRlcjIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgc2l6ZT17MTh9Lz4gVmVyaWZpY2FuZG8uLi48Lz4gOiAnU2FsdmFyIEJvdCd9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Qb3B1cD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBa0RRLFNBdUNvQixVQXZDcEI7QUFsRFIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUI7QUFFaEMsU0FBUyxRQUFlLE1BQU0sZUFBZTtBQUM3QyxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLE9BQU8sV0FBVztBQUNsQixTQUFTLGdCQUFnQjtBQUV6Qix3QkFBd0IsYUFBYTtBQUNuQyxRQUFNLENBQUMsTUFBTSxPQUFPLElBQUksZ0JBQTJCLFFBQVEsQ0FBQyxDQUFDO0FBQzdELFFBQU0sQ0FBQyxRQUFRLElBQUksZ0JBQTJCLFlBQVksQ0FBQyxDQUFDO0FBQzVELFFBQU0sQ0FBQyxhQUFhLGNBQWMsSUFBSSxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDLFlBQVksYUFBYSxJQUFJLFNBQXlCLElBQUk7QUFDakUsUUFBTSxDQUFDLFVBQVUsV0FBVyxJQUFJLFNBQVMsRUFBRSxNQUFNLElBQUksVUFBVSxJQUFJLE9BQU8sR0FBRyxDQUFDO0FBQzlFLFFBQU0sQ0FBQyxjQUFjLGVBQWUsSUFBSSxTQUFTLEtBQUs7QUFDdEQsUUFBTSxFQUFFLFNBQVMsSUFBSSxTQUFTO0FBRTlCLFFBQU0sZ0JBQWdCLE9BQU8sVUFBa0I7QUFDN0Msb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU0sV0FBVyxNQUFNLE1BQU0sK0JBQStCLEtBQUssUUFBUTtBQUN6RSxZQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7QUFDakMsVUFBSSxLQUFLLElBQUk7QUFDWCxvQkFBWSxXQUFTLEVBQUUsR0FBRyxNQUFNLE1BQU0sS0FBSyxPQUFPLFlBQVksVUFBVSxLQUFLLE9BQU8sU0FBUyxFQUFFO0FBQy9GLGlCQUFTLEVBQUUsTUFBTSxXQUFXLE9BQU8sZ0JBQWdCLFNBQVMsT0FBTyxLQUFLLE9BQU8sVUFBVSxjQUFjLENBQUM7QUFDeEcsd0JBQWdCLEtBQUs7QUFDckIsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLFNBQVMsR0FBRztBQUNWLGNBQVEsTUFBTSxDQUFDO0FBQUEsSUFDakI7QUFDQSxvQkFBZ0IsS0FBSztBQUNyQixhQUFTLEVBQUUsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLFNBQVMsb0NBQW9DLENBQUM7QUFDakcsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLGFBQWEsWUFBWTtBQUM3QixRQUFJLENBQUMsTUFBTSxjQUFjLFNBQVMsS0FBSyxFQUFHO0FBQzFDLFFBQUksWUFBWTtBQUNkLGNBQVEsS0FBSyxJQUFJLE9BQUssRUFBRSxPQUFPLFdBQVcsS0FBSyxFQUFFLEdBQUcsR0FBRyxHQUFHLFNBQVMsSUFBSSxDQUFDLENBQUM7QUFBQSxJQUMzRSxPQUFPO0FBQ0wsY0FBUSxDQUFDLEdBQUcsTUFBTSxFQUFFLElBQUksS0FBSyxJQUFJLEVBQUUsU0FBUyxHQUFHLEdBQUcsVUFBVSxRQUFRLFVBQVUsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQztBQUFBLElBQ3RIO0FBQ0EsbUJBQWUsS0FBSztBQUNwQixhQUFTLEVBQUUsTUFBTSxXQUFXLE9BQU8sYUFBYSxTQUFTLDZCQUE2QixDQUFDO0FBQUEsRUFDekY7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHNDQUFxQyxnQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLE1BQ25FLHVCQUFDLFlBQU8sU0FBUyxNQUFNO0FBQUUsc0JBQWMsSUFBSTtBQUFHLG9CQUFZLEVBQUUsTUFBTSxJQUFJLFVBQVUsSUFBSSxPQUFPLEdBQUcsQ0FBQztBQUFHLHVCQUFlLElBQUk7QUFBQSxNQUFHLEdBQUcsV0FBVSx1Q0FDbkk7QUFBQSwrQkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCO0FBQUEsUUFBRTtBQUFBLFdBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsbUJBQ0UsZUFBSyxJQUFJLENBQUMsS0FBSyxVQUNkLHVCQUFDLE9BQU8sS0FBUCxFQUF3QixTQUFTLEVBQUUsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHLFNBQVMsRUFBRSxTQUFTLEdBQUcsR0FBRyxFQUFFLEdBQUcsTUFBTSxFQUFFLFNBQVMsR0FBRyxPQUFPLElBQUksR0FBRyxZQUFZLEVBQUUsT0FBTyxRQUFRLEtBQUssR0FBRyxXQUFVLHNDQUN2SztBQUFBLDZCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwSEFBMEgsY0FBSSxLQUFLLENBQUMsS0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUo7QUFBQSxVQUNySix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFDQUFxQyxjQUFJLFFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0QsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsY0FBRSxJQUFJO0FBQUEsaUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVcsd0JBQXdCLElBQUksV0FBVyxXQUFXLGVBQWUsU0FBUyxNQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGO0FBQUEsV0FSaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMkZBQ2I7QUFBQSwrQkFBQyxVQUFLO0FBQUE7QUFBQSxVQUFTLElBQUksS0FBSyxJQUFJLGFBQWEsS0FBSyxJQUFJLENBQUMsRUFBRSxtQkFBbUI7QUFBQSxhQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsVUFBSztBQUFBO0FBQUEsVUFBTyxTQUFTLE9BQU8sT0FBSyxFQUFFLFVBQVUsSUFBSSxFQUFFLEVBQUU7QUFBQSxhQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsV0FGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFlBQU8sU0FBUyxNQUFNO0FBQUUsd0JBQWMsR0FBRztBQUFHLHNCQUFZLEVBQUUsTUFBTSxJQUFJLE1BQU0sVUFBVSxJQUFJLFVBQVUsT0FBTyxJQUFJLE1BQU0sQ0FBQztBQUFHLHlCQUFlLElBQUk7QUFBQSxRQUFHLEdBQUcsV0FBVSxvQkFBbUIsc0JBQTlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0w7QUFBQSxRQUNwTCx1QkFBQyxZQUFPLFNBQVMsTUFBTSxRQUFRLEtBQUssT0FBTyxPQUFLLEVBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQyxHQUFHLFdBQVUsK0ZBQThGLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FBN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErTDtBQUFBLFdBRmpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBbEJlLElBQUksSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxDQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBRUEsdUJBQUMsU0FBTSxRQUFRLGFBQWEsU0FBUyxNQUFNLGVBQWUsS0FBSyxHQUFHLE9BQU8sYUFBYSxlQUFlLGlCQUNuRyxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFdBQU0sTUFBSyxRQUFPLGFBQVksZUFBYyxPQUFPLFNBQVMsTUFBTSxVQUFVLE9BQUssWUFBWSxFQUFDLEdBQUcsVUFBVSxNQUFNLEVBQUUsT0FBTyxNQUFLLENBQUMsR0FBRyxXQUFVLFlBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUo7QUFBQSxNQUN2Six1QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLG1CQUFrQixPQUFPLFNBQVMsVUFBVSxVQUFVLE9BQUssWUFBWSxFQUFDLEdBQUcsVUFBVSxVQUFVLEVBQUUsT0FBTyxNQUFLLENBQUMsR0FBRyxXQUFVLFlBQTFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUs7QUFBQSxNQUNuSyx1QkFBQyxXQUFNLE1BQUssUUFBTyxhQUFZLGdCQUFlLE9BQU8sU0FBUyxPQUFPLFVBQVUsT0FBSyxZQUFZLEVBQUMsR0FBRyxVQUFVLE9BQU8sRUFBRSxPQUFPLE1BQUssQ0FBQyxHQUFHLFdBQVUsWUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwSjtBQUFBLE1BQzFKLHVCQUFDLFlBQU8sU0FBUyxZQUFZLFVBQVUsY0FBYyxXQUFVLDZEQUM1RCx5QkFBZSxtQ0FBRTtBQUFBLCtCQUFDLFdBQVEsV0FBVSxnQkFBZSxNQUFNLE1BQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUFFO0FBQUEsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RCxJQUFNLGdCQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2Q0E7QUFFSjsiLCJuYW1lcyI6W119