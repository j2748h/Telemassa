export const sendTelegramMessage = async (bot, client, message) => {
  try {
    const blocks = JSON.parse(message.content);
    for (const block of blocks) {
      let url = `https://api.telegram.org/bot${bot.token}/`;
      if (block.type === "text") {
        url += "sendMessage";
        await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: client.uid, text: block.content })
        });
      } else {
        if (!block.content) {
          console.error("Block content is empty");
          continue;
        }
        url += block.type === "image" ? "sendPhoto" : "sendVideo";
        const formData = new FormData();
        formData.append("chat_id", client.uid);
        const response = await fetch(block.content);
        if (!response.ok) {
          console.error(`Failed to fetch media: ${response.statusText}`);
          continue;
        }
        const blob = await response.blob();
        formData.append(block.type === "image" ? "photo" : "video", blob);
        await fetch(url, {
          method: "POST",
          body: formData
        });
      }
    }
  } catch (error) {
    console.error("Error sending Telegram message:", error);
    throw error;
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlbGVncmFtU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3QsIENsaWVudCwgTWVzc2FnZSB9IGZyb20gJy4uL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IHNlbmRUZWxlZ3JhbU1lc3NhZ2UgPSBhc3luYyAoYm90OiBCb3QsIGNsaWVudDogQ2xpZW50LCBtZXNzYWdlOiBNZXNzYWdlKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgYmxvY2tzID0gSlNPTi5wYXJzZShtZXNzYWdlLmNvbnRlbnQpO1xuICAgIFxuICAgIGZvciAoY29uc3QgYmxvY2sgb2YgYmxvY2tzKSB7XG4gICAgICBsZXQgdXJsID0gYGh0dHBzOi8vYXBpLnRlbGVncmFtLm9yZy9ib3Qke2JvdC50b2tlbn0vYDtcbiAgICAgIFxuICAgICAgaWYgKGJsb2NrLnR5cGUgPT09ICd0ZXh0Jykge1xuICAgICAgICB1cmwgKz0gJ3NlbmRNZXNzYWdlJztcbiAgICAgICAgYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBjaGF0X2lkOiBjbGllbnQudWlkLCB0ZXh0OiBibG9jay5jb250ZW50IH0pLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICghYmxvY2suY29udGVudCkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJCbG9jayBjb250ZW50IGlzIGVtcHR5XCIpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHVybCArPSBibG9jay50eXBlID09PSAnaW1hZ2UnID8gJ3NlbmRQaG90bycgOiAnc2VuZFZpZGVvJztcbiAgICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdjaGF0X2lkJywgY2xpZW50LnVpZCk7XG4gICAgICAgIFxuICAgICAgICAvLyBDb252ZXJ0ZSBEYXRhVVJMIG91IFVSTCBwYXJhIEJsb2JcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChibG9jay5jb250ZW50KTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBmZXRjaCBtZWRpYTogJHtyZXNwb25zZS5zdGF0dXNUZXh0fWApO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKCk7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZChibG9jay50eXBlID09PSAnaW1hZ2UnID8gJ3Bob3RvJyA6ICd2aWRlbycsIGJsb2IpO1xuICAgICAgICBcbiAgICAgICAgYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgYm9keTogZm9ybURhdGEsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2VuZGluZyBUZWxlZ3JhbSBtZXNzYWdlOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn07XG4iXSwibWFwcGluZ3MiOiJBQUVPLGFBQU0sc0JBQXNCLE9BQU8sS0FBVSxRQUFnQixZQUFxQjtBQUN2RixNQUFJO0FBQ0YsVUFBTSxTQUFTLEtBQUssTUFBTSxRQUFRLE9BQU87QUFFekMsZUFBVyxTQUFTLFFBQVE7QUFDMUIsVUFBSSxNQUFNLCtCQUErQixJQUFJLEtBQUs7QUFFbEQsVUFBSSxNQUFNLFNBQVMsUUFBUTtBQUN6QixlQUFPO0FBQ1AsY0FBTSxNQUFNLEtBQUs7QUFBQSxVQUNmLFFBQVE7QUFBQSxVQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsVUFDOUMsTUFBTSxLQUFLLFVBQVUsRUFBRSxTQUFTLE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBQUEsUUFDbkUsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLFlBQUksQ0FBQyxNQUFNLFNBQVM7QUFDbEIsa0JBQVEsTUFBTSx3QkFBd0I7QUFDdEM7QUFBQSxRQUNGO0FBQ0EsZUFBTyxNQUFNLFNBQVMsVUFBVSxjQUFjO0FBQzlDLGNBQU0sV0FBVyxJQUFJLFNBQVM7QUFDOUIsaUJBQVMsT0FBTyxXQUFXLE9BQU8sR0FBRztBQUdyQyxjQUFNLFdBQVcsTUFBTSxNQUFNLE1BQU0sT0FBTztBQUMxQyxZQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLGtCQUFRLE1BQU0sMEJBQTBCLFNBQVMsVUFBVSxFQUFFO0FBQzdEO0FBQUEsUUFDRjtBQUNBLGNBQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztBQUNqQyxpQkFBUyxPQUFPLE1BQU0sU0FBUyxVQUFVLFVBQVUsU0FBUyxJQUFJO0FBRWhFLGNBQU0sTUFBTSxLQUFLO0FBQUEsVUFDZixRQUFRO0FBQUEsVUFDUixNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGLFNBQVMsT0FBTztBQUNkLFlBQVEsTUFBTSxtQ0FBbUMsS0FBSztBQUN0RCxVQUFNO0FBQUEsRUFDUjtBQUNGOyIsIm5hbWVzIjpbXX0=